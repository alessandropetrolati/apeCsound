<CsoundSynthesizer>
<CsOptions>
</CsOptions>
<CsInstruments>

/***************************************************

Alessandro Petrolati
Out of Range
Video Luca Ceccarini
Frontone Castello, mostra collettiva Accademia di Belle Arti di Urbino
marzo 2007

Versione per apeCsound: i tre FLslider sono diventati parametri
(threshold, cf, bw) letti con chnget; la randomizzazione, che nella
versione MacCsound usava outvalue, ora usa chnset e muove gli slider.

***************************************************/

sr     = 44100   ; impostato comunque dall'host
ksmps  = 1       ; un k-cycle per campione: niente kr fisso (44100 va in
; conflitto con un host a 48000 Hz)
nchnls = 2
0dbfs  = 32767   ; scala originale

instr 1
    ; Parametri (ex FLslider)
    ; @group Amplitude selector
    krand      chnget "rand"        ; randomizzazione (nell'originale sempre attiva)
    kinterval  chnget "interval"    ; intervallo minimo tra due randomizzazioni (s, nuovo)
    kthreshold chnget "threshold"   ; selettore d'ampiezza
    
    ; @group Filter
    kcf        chnget "cf"          ; filtro risuonante: frequenza centrale
    kbw        chnget "bw"          ; filtro risuonante: banda
    
    ; @group Output
    kgain      chnget "gain"        ; volume d'uscita in dB (nuovo)
        
    ; Rumore a fondo scala: passano solo i campioni POSITIVI oltre la soglia
    ; (impulsi sparsi "fuori range")
    ksig rand 32767
    ktrig = (ksig > kthreshold ? 1 : 0)
    asig  = a(ksig * ktrig)
    
    ; Randomizzazione: a un impulso, se rand e' attivo e se e' passato almeno
    ; "interval" dall'ultima volta, nuovi valori casuali per filtro, soglia e
    ; posizione stereo. chnset al posto di outvalue: gli slider si muovono.
    ; Il limite di tempo e' necessario: cambiare frequenza e banda di reson a
    ; OGNI impulso (circa 1800 volte al secondo) rende il filtro instabile
    ; (in simulazione picchi oltre +100 dB: "esplode"). Nella versione 2007
    ; i valori arrivavano al filtro solo tramite gli slider della GUI, cioe'
    ; poche volte al secondo. Con 0.25 s i picchi restano entro circa +6 dB.
    kwidth init 0
    klast  init -100
    ktime  timeinsts
    if (ktrig == 1 && krand == 1 && ktime - klast >= max(kinterval, 0.05)) then
        klast  = ktime
        kRcf   random 20, 20000
        kRbw   random 1, 100
        kRtr   random 30000, 32760
        kwidth random -1, 1
        
        chnset kRcf, "cf"
        chnset kRbw, "bw"
        chnset kRtr, "threshold"
    endif
    
    ; Filtro risuonante (NORMALE). Varianti dell'originale:
    ;	asig resonr asig, kcf, kbw		;PULITO
    ;	asig resonx asig, kcf, kbw		;VIOLENTO
    ;	asig resonz asig, kcf, kbw		;OK
    ;	asig butterbp asig, kcf, kbw	;SOLO ALTE
    asig reson asig, limit(kcf, 20, 20000), limit(kbw, 1, 1000), 2
    
    ; Posizione stereo a tre stati, scelta a ogni impulso: sinistra, destra o
    ; centro. Nell'originale la catena di goto finiva sempre nel ramo
    ; "entrambi" (la condizione kwidth < -0.5 && kwidth > 0.5 non e' mai
    ; vera): qui e' implementata la versione if/elseif che era commentata.
    if (kwidth > 0.5) then
        asigL = asig
        asigR = 0
    elseif (kwidth < -0.5) then
        asigL = 0
        asigR = asig
    else
        asigL = asig
        asigR = asig
    endif
    
    ; reson con iscl = 2 (normalizzazione RMS): senza scala il guadagno
    ; dipende enormemente da frequenza e banda (da +16 a +83 dB sopra il
    ; fondo scala con questi impulsi, simulazione a 48 kHz), quindi
    ; con la randomizzazione il volume saltava di decine di dB. Normalizzato
    ; il picco resta tra circa -7 e +3 dB: "gain" regola il volume finale.
    ; Sicurezza: limite rigido a 0dbfs dopo il volume.
    kamp  = ampdb(kgain)
    asigL clip asigL * kamp, 0, 0dbfs
    asigR clip asigR * kamp, 0, 0dbfs
    outs asigL, asigR
endin

</CsInstruments>
<CsScore>
i1 0 9999
e
</CsScore>
</CsoundSynthesizer>

<apeCsoundParams>
<?xml version="1.0" encoding="UTF-8"?>

<APE_CSOUND_STATE>
  <CHANNEL_PARAM_SLOTS>
    <SLOT index="1" channel="cf" min="20.0" max="20000.0" default="1000.0"
          skew="0.300000011920929" step="0.0"/>
    <SLOT index="2" channel="bw" min="1.0" max="100.0" default="10.0" skew="1.0"
          step="0.0"/>
    <SLOT index="3" channel="gain" min="-60.0" max="0.0" default="-12.0"
          skew="1.0" step="0.0"/>
    <SLOT index="4" channel="interval" min="0.05000000074505806" max="2.0"
          default="0.25" skew="0.25" step="0.0"/>
  </CHANNEL_PARAM_SLOTS>
  <INT_PARAM_SLOTS>
    <SLOT index="0" channel="threshold" min="30000" max="32767" default="0"/>
  </INT_PARAM_SLOTS>
  <BOOL_PARAM_SLOTS>
    <SLOT index="0" channel="rand" default="1"/>
  </BOOL_PARAM_SLOTS>
  <CHOICE_PARAM_SLOTS/>
</APE_CSOUND_STATE>

</apeCsoundParams>
