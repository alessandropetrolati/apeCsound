<Cabbage> bounds(0, 0, 0, 0)
form caption("Untitled") size(330, 160), guiMode("queue") pluginId("slc1")
rslider bounds(116, 8, 100, 100), channel("SEQ_LEN"), range(0.1, 10, 2, 1, 0.01), text("LENGTH"), trackerColour(0, 255, 0, 255), outlineColour(0, 0, 0, 50), textColour(0, 0, 0, 255)
rslider bounds(8, 8, 100, 100), channel("SEQ_AMOUNT"), range(0, 1, 0.5, 1, 0.01), text("AMOUNT"), trackerColour(0, 255, 0, 255), outlineColour(0, 0, 0, 50), textColour(0, 0, 0, 255)

rslider bounds(220, 8, 100, 100), channel("SEQ_REPEAT"), range(1, 24, 4, 1, 1), text("REPEAT"), trackerColour(0, 255, 0, 255), outlineColour(0, 0, 0, 50), textColour(0, 0, 0, 255)



combobox bounds(8, 114, 146, 32) channel("SEQ_MODE") text("Forward", "Backward", "Random") value(1)
combobox bounds(190, 112, 130, 34) channel("SEQ_ENV") text("Envelope OFF", "Envelope ON") value(1)
</Cabbage>
<CsoundSynthesizer>
<CsOptions>
-n -d
</CsOptions>
<CsInstruments>
; Initialize the global variables. 
ksmps = 32
nchnls = 2
0dbfs = 1

;Author: Alessandro Petrolati
;http://www.apesoft.it

#define MAX_SLICE_LEN #10# ;sec (maxvalue of SEQ_LEN)
gitblslicer init -1

opcode apeSlicer, a, akkkkii
    asig, klength, krepeat, kmode, kenvon, itbl, iwin xin
    
    setksmps 1
    
    kwndx init 0
    aout init 0
    
    ilen init ftlen(itbl)
    
    kwndx = (kwndx < ilen ? kwndx+1 : 0)
    tablew asig, a(kwndx), itbl, 0
    
    ;freeze values for the sub-phrases
    reset:
    ;0 = forward
    ;1 = backward
    ;2 = random
    imode init i(kmode)
    if imode <= 1 then
        idir init imode
    else
        irnd random 1, 0
        idir init round(irnd)
    endif
    
    iseglength = i(klength)*sr
    isublen init iseglength/i(krepeat)
    indxhold init i(kwndx)
    kreadndx init 0
    
    timout 0, i(klength), continuee
    reinit reset
    
    continuee:	
    kreadndx = (kreadndx < isublen ? kreadndx+1 : 0)
    kndxnorm = kreadndx/isublen
    
    if k(idir) == 0 then ;forward
        kreadndxres = kreadndx - isublen
    else ;backward
        kreadndxres = -kreadndx
    endif
    
    rireturn
    asig table indxhold+kreadndxres, itbl, 0, 0, 1
    awin table3 kndxnorm, iwin, 1
    kwin downsamp awin
    aout = asig * (kenvon == 1 ? kwin : 1)
    xout aout
endop


opcode findPowerOfTwo, i, i
    
    iseconds	xin
    
    isamples	= iseconds * sr
    
    ipowtwosamples = 2
    
    loop:
    
    ipowtwosamples = ipowtwosamples * 2
    
    if ipowtwosamples < isamples igoto loop
    
    xout ipowtwosamples
    
endop


;==================================================================================
instr 1 ; SLICER
    ;==================================================================================
    
    ;create table to hold samples for the slicer UDO
    ilen findPowerOfTwo $MAX_SLICE_LEN
    gitblslicer ftgen 0, 0, ilen, 7, 0, ilen, 0
    
    a1 inch 1
    a2 inch 2
    
    ainput = a1;oscil 0.2, 440
    
    kamount chnget "SEQ_AMOUNT" ;0 a 4 def 2
    ksegLength chnget "SEQ_LEN" ;0.1 a 10 def 2 ;
    kmode chnget "SEQ_MODE"
    kmode = kmode - 1
    krepeat chnget "SEQ_REPEAT" ;1 a 24 def 4 
    kenvmode chnget "SEQ_ENV"
    kenvmode = kenvmode - 1
    
    iwin init 143
    
    kenv linsegr 0, 0.707, 1, 0.707, 0
    aenv interp kenv*kamount
    asig apeSlicer ainput, ksegLength, krepeat, kmode, kenvmode, gitblslicer, iwin
    
    ares = asig*aenv
    outch 1, ares
    outch 2, ares
    
endin

</CsInstruments>
<CsScore>
; Create table to hold the trapezoid envelope used by SLICER UDO
f143 0  4097 7 0 128 1 3840 1 128 0 1 0

;starts instrument 1 and runs it for a week
i1 1 z
</CsScore>
</CsoundSynthesizer>

<apeCsoundParams>
<?xml version="1.0" encoding="UTF-8"?>

<APE_CSOUND_STATE>
  <CHANNEL_PARAM_SLOTS>
    <SLOT index="0" channel="SEQ_LEN" min="0.1000000014901161" max="10.0"
          default="2.0" skew="1.0" step="0.009999999776482582"/>
    <SLOT index="1" channel="SEQ_AMOUNT" min="0.0" max="1.0" default="0.5"
          skew="1.0" step="0.009999999776482582"/>
    <SLOT index="2" channel="SEQ_REPEAT" min="1.0" max="24.0" default="4.0"
          skew="1.0" step="1.0"/>
  </CHANNEL_PARAM_SLOTS>
  <INT_PARAM_SLOTS/>
  <BOOL_PARAM_SLOTS/>
  <CHOICE_PARAM_SLOTS>
    <SLOT index="0" channel="SEQ_MODE" defaultIndex="1" options="Forward&#10;Backward&#10;Random"/>
    <SLOT index="1" channel="SEQ_ENV" defaultIndex="1" options="Envelope OFF&#10;Envelope ON"/>
  </CHOICE_PARAM_SLOTS>
</APE_CSOUND_STATE>

</apeCsoundParams>
