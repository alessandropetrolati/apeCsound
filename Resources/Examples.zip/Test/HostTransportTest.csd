<CsoundSynthesizer>
<CsOptions>
</CsOptions>
<CsInstruments>

/*
  HostTransportTest - the DAW transport as control channels (same names
  as Cabbage): HOST_BPM, IS_PLAYING, IS_RECORDING, HOST_PPQ_POS,
  HOST_PPQ_BAR_START, TIME_IN_SECONDS, TIME_IN_SAMPLES, TIME_SIG_NUM,
  TIME_SIG_DENOM. Updated once per audio block.

  Load it in a DAW, press Apply, then Play:
  - instr 1 prints bpm / playing / beat position once per second
  - instr 2 is a metronome: a tick on every beat, higher on the first
    beat of the bar, only while the host is playing. Change the tempo or
    the time signature in the DAW and listen.
  - instr 3 is a tempo-synced delay on the track input (dotted 1/8):
    send some audio into the track and change the tempo.

  Standalone (no transport): HOST_BPM = 120, 4/4, IS_PLAYING = 0, so the
  metronome stays silent and the delay runs at 120.
*/

sr     = 48000
ksmps  = 32
nchnls = 2
0dbfs  = 1

instr 1 ; monitor
  kbpm   chnget "HOST_BPM"
  kplay  chnget "IS_PLAYING"
  krec   chnget "IS_RECORDING"
  kppq   chnget "HOST_PPQ_POS"
  kbar   chnget "HOST_PPQ_BAR_START"
  ksec   chnget "TIME_IN_SECONDS"
  knum   chnget "TIME_SIG_NUM"
  kden   chnget "TIME_SIG_DENOM"
  ktick  metro 1
  if ktick == 1 then
    printks "bpm %.1f  play %d  rec %d  ppq %.2f  bar %.2f  sec %.2f  sig %d/%d\n", 0, kbpm, kplay, krec, kppq, kbar, ksec, knum, kden
  endif
endin

instr 2 ; metronome from HOST_PPQ_POS
  kplay chnget "IS_PLAYING"
  kppq  chnget "HOST_PPQ_POS"
  kbar  chnget "HOST_PPQ_BAR_START"
  knum  chnget "TIME_SIG_NUM"
  kden  chnget "TIME_SIG_DENOM"
  kbeatlen = 4 / (kden > 0 ? kden : 4)        ; one beat in quarter notes
  kbeat    = floor((kppq - kbar) / kbeatlen)  ; beat index within the bar
  kprev    init -1
  if kplay == 1 && kbeat != kprev then
    kprev = kbeat
    schedulek 10, 0, 0.08, (kbeat == 0 ? 1760 : 880)
  elseif kplay == 0 then
    kprev = -1
  endif
endin

instr 10 ; tick
  aenv expseg 1, p3, 0.001
  asig oscili 0.3 * aenv, p4
  outch 1, asig, 2, asig
endin

instr 3 ; tempo-synced delay, dotted 1/8
  kbpm  chnget "HOST_BPM"
  kbpm  = (kbpm > 0 ? kbpm : 120)
  kdel  = 60 / kbpm * 0.75
  kdel  port kdel, 0.1
  aInL  inch 1
  aInR  inch 2
  abuf  delayr 4
  adel  deltapi kdel
        delayw (aInL + aInR) * 0.5 + adel * 0.5
  outch 1, aInL + adel * 0.6, 2, aInR + adel * 0.6
endin

</CsInstruments>
<CsScore>
i1 0 z
i2 0 z
i3 0 z
e
</CsScore>
</CsoundSynthesizer>
