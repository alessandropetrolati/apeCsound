<CsoundSynthesizer>
<CsOptions>
</CsOptions>
<CsInstruments>

/*
  XYPadTest - two Float parameters shown as one XY pad.

  "; @xy "Cutoff" "Resonance"" below turns the two sliders into a single
  pad card (X = Cutoff, Y = Resonance). They are still two separate DAW
  parameters: automate them, save them in snapshots, randomize them.

  After Apply the panel must show:
    Filter (1): the Cutoff / Resonance pad
    Other  (1): Volume (a normal slider)

  Try:
  - drag inside the pad: the filter follows both axes at once
  - double-click the pad: both back to their init values
  - the pencil: the Edit card with BOTH channel fields (X, then Y below)
    and the range fields of X; "..." > Edit Y: Resonance shows the range
    fields of Y; the check mark goes back to the pad
  - put the caret on the "Resonance" chnget line: the pad flashes
  - delete the @xy comment and Apply: two sliders again
*/

sr     = 48000
ksmps  = 32
nchnls = 2
0dbfs  = 1

instr 1
  ; @group Filter
  ; @xy "Cutoff" "Resonance"
  kcut  chnget "Cutoff"
  kres  chnget "Resonance"
  kvol  chnget "Volume"

  a1 vco2 0.3, 55
  a2 vco2 0.3, 55.3
  asig moogladder a1 + a2, port(kcut, 0.02), port(kres, 0.02)
  asig = asig * port(kvol, 0.02)
  outch 1, asig, 2, asig
endin

</CsInstruments>
<CsScore>
i1 0 z
e
</CsScore>
</CsoundSynthesizer>
<apeCsoundParams>
<?xml version="1.0" encoding="UTF-8"?>

<APE_CSOUND_STATE>
  <CHANNEL_PARAM_SLOTS>
    <SLOT index="0" channel="Cutoff" min="100.0" max="8000.0" default="1200.0"
          skew="0.4" step="0.0"/>
    <SLOT index="1" channel="Resonance" min="0.0" max="0.9" default="0.3"
          skew="1.0" step="0.0"/>
    <SLOT index="2" channel="Volume" min="0.0" max="1.0" default="0.7"
          skew="1.0" step="0.0"/>
  </CHANNEL_PARAM_SLOTS>
  <INT_PARAM_SLOTS/>
  <BOOL_PARAM_SLOTS/>
  <CHOICE_PARAM_SLOTS/>
</APE_CSOUND_STATE>

</apeCsoundParams>
