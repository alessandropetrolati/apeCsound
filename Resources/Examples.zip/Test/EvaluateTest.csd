<CsoundSynthesizer>
<CsOptions>
</CsOptions>
<CsInstruments>

/*
  EvaluateTest - try "Evaluate" (live coding).

  Shift+Return in the editor (or right-click > Evaluate) sends to the
  running engine the selection, or the instr/opcode block around the
  caret, or the current line - WITHOUT a full recompile. The Evaluate
  line (round ">_" button at the top right of the Console, above the
  trash, or Cmd+E) does the same for a single line.

  Press Apply once: a continuous pad starts (instr 1, always on).
  Then, in order:

  1. SCORE EVENT from the Evaluate line
     Click the round ">_" button on the Console (or Cmd+E) and type:   i 2 0 2
     -> a 2-second "blip" on top of the pad. Try  i 2 0 0.3
     and  i 2 0 1 880   (p4 = frequency).

  2. SELECTION from the editor
     Select ONLY the text between the square brackets (we are inside a
     comment, so the whole line would not do) and press Shift+Return:
        [schedule(2, 0, 1, 660)]
     the selection flashes and the blip plays. Outside comments, just
     put the caret on the line, no selection needed.

  3. REDEFINE AN INSTRUMENT WHILE IT PLAYS
     In instr 2 change the last argument of vco2 from 0 to 10 (square),
     or the release of linen from 0.15 to 1 (p3 is still the duration),
     put the caret inside instr 2 and press Shift+Return: the whole block
     flashes. From now on  i 2 0 1  uses the new version. The pad
     (instr 1) was NOT interrupted: Apply would have stopped and
     restarted it.

  4. GLOBAL STATE
     Evaluate the line:   gkpadamp = 0.05
     the pad gets quieter at once. Then  gkpadamp = 0.2  to bring it
     back. Evaluate  gkpadcps = 110  or  gkpadcps = 220.

  5. THE PAD CAN BE REDEFINED TOO
     Change something in instr 1 and evaluate the block: the running note
     keeps the OLD version (it stays on). To hear the new one evaluate
     turnoff2_i 1, 0, 1   (stops the old one) and then
     i 1 0 -1   (starts it again with the new definition).

  6. ERROR
     Evaluate   a1 oscil 0.1, 440, 999999   (no such table): the error
     shows up in the console and the engine keeps playing.

  Note: nothing you evaluate is saved anywhere. At the next Apply (or
  when the project is reopened) only the text in the editor counts.
*/

sr     = 48000
ksmps  = 32
nchnls = 2
0dbfs  = 1

gkpadamp init 0.2
gkpadcps init 110

instr 1 ; continuous pad (started by the score, i1 0 z)
  kamp port gkpadamp, 0.1
  kcps port gkpadcps, 0.1
  a1 vco2 kamp, kcps, 10          ; square
  a2 vco2 kamp, kcps * 1.005
  asig moogladder a1 + a2, 1200, 0.3
  outch 1, asig, 2, asig
endin

instr 2 ; blip: i 2 start dur [cps]
  icps = (p4 > 0 ? p4 : 440)
  ; envelope: 10 ms attack, sustain, 150 ms release within p3
  kenv linen 0.4, 0.01, p3, 0.15
  asig vco2 kenv, icps, 0       ; saw - try: 10 = square, 12 = triangle,
                                ; or  oscili kenv, icps  (sine)
  asig butlp asig, 3000
  outch 1, asig, 2, asig
endin

</CsInstruments>
<CsScore>
i1 0 z
e
</CsScore>
</CsoundSynthesizer>

<apeCsoundParams>
<?xml version="1.0" encoding="UTF-8"?>

<APE_CSOUND_STATE>
  <CHANNEL_PARAM_SLOTS/>
  <INT_PARAM_SLOTS/>
  <BOOL_PARAM_SLOTS/>
  <CHOICE_PARAM_SLOTS/>
</APE_CSOUND_STATE>

</apeCsoundParams>
