<CsoundSynthesizer>
<CsOptions>
</CsOptions>
<CsInstruments>

/*
  MonitorStressTest - a patch that writes MANY channels with chnset and
  exercises EVERY kind of output apeCsound supports.

  A self-contained generative synth (no input needed). After Apply the
  Parameters panel must show:

  1. MONITOR - METERS WITH RANGE (chn_k hints: fixed bar)
       OutRMS_dB, OutPeak_dB (-60..0), Vel, Gate, EnvA, EnvF, EnvAmp_dB
     + AUDIO METERS: Out1, Out2 (chnset aL / aR) are one card with two
       segmented meters in dB; OutPeak_1, OutPeak_2 one card with two bars
     + SPARKLINES (the only attribute, "spark"): Pitch_Hz, Centroid_Hz
     + LAMP: Gate takes only 0 and 1, so it becomes a lamp by itself
  2. MONITOR - VALUES WITHOUT RANGE (the bar adapts to the values seen)
       Freq, Bar, Beat, BPM, Events, Seconds
     + AUTOMATIC GROUPS by name: LFO1..LFO4 (sine, tri, square, saw),
       Rand_1..Rand_4 (+-1, +-10, +-5, +-100), Band_1..Band_8 and
       Late_1..Late_6 each become ONE card with a bar per channel
  3. MONITOR - STRINGS (text instead of a bar)
       NoteName ("C#3"), StepText ("bar 3  beat 2  step 05  x"),
       Scale (changes every bar), Status (one line of state, 4 times/s)
  4. MONITOR - CHANNELS CREATED AT RUN TIME (appear within a second)
       Late_1..Late_6, one every 10 seconds (each one is written by its
       own instance of instr 7, started with "event": the channel does not
       exist before that). Band_1..Band_8 are declared with chn_k, so their
       card is there from the start; the bars move only while "Spectrum"
       is ON.
  5. WRITE-BACK TO PARAMETERS (chnset on a parameter channel moves the
     control and flashes the "external change" dot; nothing in Monitor)
       Float  "FollowLFO"  slider follows a slow sine
       Int    "StepOut"    0..15, the current sequencer step
       Bool   "Blink"      ON on every beat, OFF in between
       Choice "LastNote"   menu set to the pitch class of the last note
       XY pad "PadX"/"PadY" (; @xy after this comment) the dot draws a Lissajous curve
     Moving one of them by hand is overridden at the next write.
  7. GRAPHS PANEL (menu > Show Graphs): "ftable 100" is a live scope of
     the output and "ftable 101" a live envelope, both rewritten with
     tablew and redrawn by the panel when they change.
  6. HOST CHANNELS ARE NEVER SHOWN: HOST_BPM, IS_PLAYING... are read here
     (HostBPM copies HOST_BPM into a Monitor channel) but the reserved
     names themselves must not appear in Monitor.

  Knobs: "Tempo", "Density", "Root", "ScaleSel" drive the sequencer;
  "Cutoff", "Res" the filter; "Rate" (1..200 Hz) how often the analysis
  channels are written - at 200 the panel must stay fluid (the UI reads
  at 20 Hz, whatever the write rate); "Spectrum" adds/stops 8 channels;
  "WriteBack" ON/OFF enables section 5.

*/

; @xy "PadX" "PadY"

sr     = 48000
ksmps  = 32
nchnls = 2
0dbfs  = 1

; ---- channels with range hints (chn_k: name, mode 2 = output, itype 2 =
;      linear, default, min, max): the Monitor bar uses them
; ---- the only attribute (11th argument of chn_k, see the Guide > Monitor):
;      "spark" sparkline of the last 5 s instead of the bar.
;      Channels "Base1, Base2..." / "Base_1, Base_2..." become one multi-bar
;      card by themselves.
;      are grouped into one card automatically (Band_1..8, LFO1..4, Late_1..).
chn_k "OutPeak_1",   2, 2, 0, 0, 1
chn_k "OutPeak_2",   2, 2, 0, 0, 1
chn_k "OutRMS_dB",   2, 2, -60, -60, 0
chn_k "OutPeak_dB",  2, 2, -60, -60, 0
chn_k "Pitch_Hz",    2, 2, 0, 0, 2000, 0, 0, 0, 0, "spark"
chn_k "Centroid_Hz", 2, 2, 0, 0, 8000, 0, 0, 0, 0, "spark"
chn_k "Step",        2, 2, 0, 0, 15
chn_k "Note",        2, 2, 60, 36, 96
chn_k "Vel",         2, 2, 0, 0, 1
chn_k "Gate",        2, 2, 0, 0, 1
chn_k "EnvA",        2, 2, 0, 0, 1
chn_k "EnvF",        2, 2, 0, 0, 1
chn_k "EnvAmp_dB",   2, 2, -60, -60, 0
chn_k "Voices",      2, 2, 0, 0, 8
chn_k "Band_1", 2, 2, 0, 0, 1
chn_k "Band_2", 2, 2, 0, 0, 1
chn_k "Band_3", 2, 2, 0, 0, 1
chn_k "Band_4", 2, 2, 0, 0, 1
chn_k "Band_5", 2, 2, 0, 0, 1
chn_k "Band_6", 2, 2, 0, 0, 1
chn_k "Band_7", 2, 2, 0, 0, 1
chn_k "Band_8", 2, 2, 0, 0, 1

gaOutL init 0
gaOutR init 0
gaScopeL init 0
gaScopeR init 0
gkVoices init 0
gkEvents init 0
gkEnvA init 0
gkEnvF init 0

gSNames[] fillarray "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"
giMinor[] fillarray 0, 2, 3, 5, 7, 8, 10, 12
giDorian[] fillarray 0, 2, 3, 5, 7, 9, 10, 12
giLydian[] fillarray 0, 2, 4, 6, 7, 9, 11, 12

; ---------------------------------------------------------------- sequencer
instr 1
  ktempo   chnget "Tempo"       ; 40..240 BPM
  kdensity chnget "Density"     ; 0..1 probability of a note per step
  kroot    chnget "Root"        ; MIDI note 36..60 (Int)
  kscale   chnget "ScaleSel"    ; menu: 1 = minor, 2 = dorian, 3 = lydian

  ktick    metro ktempo / 60 * 4          ; 16th notes
  kstep    init 0
  kbar     init 0
  kbeat    init 0

  ; a new scale name once per bar
  if ktick == 1 then
    if kstep == 0 then
      kbar += 1
      Sscale = (kscale == 1 ? "minor" : (kscale == 2 ? "dorian" : "lydian"))
      chnset Sscale, "Scale"
    endif
    kbeat = floor(kstep / 4)

    ; pick a note
    kdeg = int(random:k(0, 8))
    if kscale == 1 then
      kiv = giMinor[kdeg]
    elseif kscale == 2 then
      kiv = giDorian[kdeg]
    else
      kiv = giLydian[kdeg]
    endif
    koct  = int(random:k(0, 3)) * 12
    knote = kroot + kiv + koct
    kvel  = random:k(0.3, 1)

    kplay = (random:k(0, 1) < kdensity ? 1 : 0)
    if kplay == 1 then
      kdur = 60 / ktempo * random:k(0.2, 1.5)
      event "i", 2, 0, kdur, knote, kvel
      gkEvents += 1
      Sname sprintfk "%s%d", gSNames[knote % 12], int(knote / 12) - 1
      chnset Sname, "NoteName"
    endif

    Sstep sprintfk "bar %d  beat %d  step %02d  %s", kbar, kbeat + 1, kstep, (kplay == 1 ? "x" : "-")
    chnset Sstep, "StepText"

    chnset kstep,  "Step"
    chnset knote,  "Note"
    chnset cpsmidinn(knote), "Freq"
    chnset kvel * kplay, "Vel"
    chnset kplay,  "Gate"
    chnset kbar,   "Bar"
    chnset kbeat + 1, "Beat"
    chnset ktempo, "BPM"
    chnset gkEvents, "Events"

    kstep = (kstep + 1) % 16
  endif
endin

; ---------------------------------------------------------------- voice
instr 2
  inote = p4
  ivel  = p5
  gkVoices += 1

  kcut  chnget "Cutoff"
  kres  chnget "Res"

  kenvA madsr 0.005, 0.1, 0.6, 0.15
  kenvF madsr 0.01, 0.3, 0.2, 0.2
  a1    vco2 ivel * 0.25, cpsmidinn(inote), 0
  a2    vco2 ivel * 0.25, cpsmidinn(inote) * 1.004, 10
  asig  moogladder a1 + a2, kcut * (0.3 + 0.7 * kenvF), kres
  asig  = asig * kenvA
  ipan  = random(0.2, 0.8)
  gaOutL += asig * sqrt(1 - ipan)
  gaOutR += asig * sqrt(ipan)

  ; the loudest voice wins the envelope readouts
  gkEnvA = max(gkEnvA, kenvA * ivel)
  gkEnvF = max(gkEnvF, kenvF)
  if release() == 1 then
    kdone init 0
    if kdone == 0 then
      gkVoices -= 1
      kdone = 1
    endif
  endif
endin

; ---------------------------------------------------------------- modulators
instr 3
  chnset oscil:k(1, 0.1),           "LFO1"      ; sine
  chnset lfo:k(1, 0.23, 1),         "LFO2"      ; triangle
  chnset lfo:k(1, 0.37, 2),         "LFO3"      ; square
  chnset lfo:k(1, 0.5, 4),          "LFO4"      ; saw down
  chnset randi:k(1, 3),             "Rand_1"
  chnset randh:k(10, 2),            "Rand_2"
  chnset jspline(5, 0.5, 2),        "Rand_3"
  chnset rspline(-100, 100, 0.3, 1),"Rand_4"
endin

; ---------------------------------------------------------------- analysis + output
instr 4
  krate chnget "Rate"
  kspec chnget "Spectrum"
  aL = gaOutL
  aR = gaOutR
  gaOutL = 0
  gaOutR = 0

  ; soft clip and out
  aL = tanh(aL)
  aR = tanh(aR)
  outch 1, aL, 2, aR
  gaScopeL = aL      ; for the scope table (instr 6)
  gaScopeR = aR

  ; --- analysis written "krate" times per second
  kgo metro krate
  chnset aL, "Out1"              ; audio channels: level meters in the Monitor
  chnset aR, "Out2"
  krmsL rms aL
  krmsR rms aR
  kpkL  max_k aL, kgo, 1
  kpkR  max_k aR, kgo, 1
  kcps, kamp ptrack aL, 1024
  kcent centroid aL, kgo, 2048
  if kgo == 1 then
    chnset kpkL,  "OutPeak_1"
    chnset kpkR,  "OutPeak_2"
    kdb = (krmsL + krmsR > 0.000002 ? dbamp((krmsL + krmsR) * 0.5) : -60)
    chnset limit(kdb, -60, 0), "OutRMS_dB"
    kpdb = (max(kpkL, kpkR) > 0.000001 ? dbamp(max(kpkL, kpkR)) : -60)
    chnset limit(kpdb, -60, 0), "OutPeak_dB"
    chnset (kamp > 0.01 ? kcps : 0), "Pitch_Hz"
    chnset kcent, "Centroid_Hz"
    chnset gkEnvA, "EnvA"
    chnset gkEnvF, "EnvF"
    chnset (gkEnvA > 0.000001 ? limit(dbamp(gkEnvA), -60, 0) : -60), "EnvAmp_dB"
    chnset gkVoices, "Voices"
    gkEnvA = 0
    gkEnvF = 0
  endif

  ; --- 8 band meters, only while Spectrum is ON (channels appear at run time)
  if kspec == 1 then
    amono = (aL + aR) * 0.5
    kb metro 25
    ab1 butbp amono, 60, 60
    ab2 butbp amono, 150, 120
    ab3 butbp amono, 350, 250
    ab4 butbp amono, 800, 500
    ab5 butbp amono, 1800, 1000
    ab6 butbp amono, 4000, 2000
    ab7 butbp amono, 8000, 4000
    ab8 buthp amono, 11000
    if kb == 1 then
      chnset rms:k(ab1) * 4, "Band_1"
      chnset rms:k(ab2) * 4, "Band_2"
      chnset rms:k(ab3) * 4, "Band_3"
      chnset rms:k(ab4) * 4, "Band_4"
      chnset rms:k(ab5) * 4, "Band_5"
      chnset rms:k(ab6) * 4, "Band_6"
      chnset rms:k(ab7) * 4, "Band_7"
      chnset rms:k(ab8) * 4, "Band_8"
    endif
  endif

  ; --- status
  if metro(4) == 1 then
    chnset timeinsts(), "Seconds"
    Sst sprintfk "%d voices, rate %d Hz, spectrum %s", gkVoices, krate, (kspec == 1 ? "on" : "off")
    chnset Sst, "Status"
  endif

  ; --- a new channel every 10 seconds, up to Late_6. A chnset creates its
  ; channel at INIT time, even inside an "if" that is false: to create a
  ; channel later, start an instrument later (instr 7, name built at i-time).
  klate init 0
  if timeinsts() > (klate + 1) * 10 && klate < 6 then
    klate += 1
    event "i", 7, 0, -1, klate
  endif
endin

; ---------------------------------------------------------------- run-time channels
instr 7
  Slate sprintf "Late_%d", p4          ; i-time: the name is right at init
  chnset timeinsts() + p4 * 10, Slate
endin

; ---------------------------------------------------------------- live tables (Graphs panel)
; Menu > Show Graphs: "ftable 100" is a scope of the output (rewritten every
; k-cycle with tablew), "ftable 101" the filter envelope of the last voice.
; The panel re-reads tables ~4 times per second and redraws them when they
; change - no display opcode needed.
giScope ftgen 100, 0, 2048, 2, 0
giEnvTb ftgen 101, 0, 256, 2, 0

instr 6
  aMono = (gaScopeL + gaScopeR) * 0.5   ; output of instr 4 (runs before instr 6)
  aPhs phasor sr / ftlen(giScope)
  tablew aMono, aPhs, giScope, 1
  ; envelope table: redrawn from the current Env values 8 times per second
  if metro(8) == 1 then
    kidx = 0
    while kidx < ftlen(giEnvTb) do
      tablew gkEnvA * (1 - kidx / ftlen(giEnvTb)), kidx, giEnvTb
      kidx += 1
    od
  endif
endin

; ---------------------------------------------------------------- write-back to parameters
instr 5
  kon chnget "WriteBack"
  if kon == 1 then
    ; Float slider: follows a slow sine (0..1)
    chnset 0.5 + 0.5 * oscil:k(1, 0.07), "FollowLFO"
    ; XY pad: Lissajous figure
    chnset 0.5 + 0.45 * oscil:k(1, 0.11),       "PadX"
    chnset 0.5 + 0.45 * oscil:k(1, 0.17, -1, 0.25), "PadY"
    ; Int: current step (0..15), written only when it changes
    kstep chnget "Step"
    if changed(kstep) == 1 then
      chnset kstep, "StepOut"
    endif
    ; Bool: ON on the beat, OFF in between
    ktempo chnget "Tempo"
    kbeat  metro ktempo / 60
    kblink init 0
    if kbeat == 1 then
      kblink = 1
    elseif kblink == 1 && metro(ktempo / 60 * 4) == 1 then
      kblink = 0
    endif
    if changed(kblink) == 1 then
      chnset kblink, "Blink"
    endif
    ; Choice: pitch class of the last note (menu index is 1-based)
    knote chnget "Note"
    if changed(knote) == 1 then
      chnset (knote % 12) + 1, "LastNote"
    endif
  endif

  ; host channels: read, re-published under another name (section 6)
  chnset chnget:k("HOST_BPM"), "HostBPM"
endin

</CsInstruments>
<CsScore>
i1 0 z
i3 0 z
i4 0 z
i5 0 z
i6 0 z
e
</CsScore>
</CsoundSynthesizer>

<apeCsoundParams>
<?xml version="1.0" encoding="UTF-8"?>

<APE_CSOUND_STATE>
  <CHANNEL_PARAM_SLOTS>
    <SLOT index="0" channel="Tempo" min="40.0" max="240.0" default="110.0"
          skew="1.0" step="1.0"/>
    <SLOT index="1" channel="Density" min="0.0" max="1.0" default="0.6000000238418579"
          skew="1.0" step="0.0"/>
    <SLOT index="2" channel="Cutoff" min="100.0" max="12000.0" default="2500.0"
          skew="0.4000000059604645" step="0.0"/>
    <SLOT index="3" channel="Res" min="0.0" max="0.949999988079071" default="0.4000000059604645"
          skew="1.0" step="0.0"/>
    <SLOT index="4" channel="Rate" min="1.0" max="200.0" default="30.0"
          skew="0.5" step="1.0"/>
  </CHANNEL_PARAM_SLOTS>
  <INT_PARAM_SLOTS>
    <SLOT index="0" channel="Root" min="36" max="60" default="48"/>
    <SLOT index="1" channel="StepOut" min="0" max="15" default="0"/>
  </INT_PARAM_SLOTS>
  <BOOL_PARAM_SLOTS>
    <SLOT index="0" channel="Spectrum" default="0"/>
    <SLOT index="1" channel="WriteBack" default="1"/>
    <SLOT index="2" channel="Blink" default="0"/>
  </BOOL_PARAM_SLOTS>
  <CHOICE_PARAM_SLOTS>
    <SLOT index="0" channel="ScaleSel" defaultIndex="0" options="minor&#10;dorian&#10;lydian"/>
    <SLOT index="1" channel="LastNote" defaultIndex="0" options="C&#10;C#&#10;D&#10;D#&#10;E&#10;F&#10;F#&#10;G&#10;G#&#10;A&#10;A#&#10;B"/>
  </CHOICE_PARAM_SLOTS>
</APE_CSOUND_STATE>

</apeCsoundParams>
