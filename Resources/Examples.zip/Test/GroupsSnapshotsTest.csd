<CsoundSynthesizer>
<CsOptions>
</CsOptions>
<CsInstruments>

/*
  GroupsSnapshotsTest - test dei GRUPPI nel pannello Parameters e degli
  SNAPSHOT dei valori.

  GRUPPI ("; @group Nome" nel codice):
  - dopo Apply il pannello deve mostrare, in quest'ordine:
      Synth  (4): Cutoff, Wave, Gate, Resonance
      Delay  (3): DelayTime, Feedback, Sync
      Master (2): Volume, Mute
      Other  (1): Unused
    Wave (menu) e Gate (toggle) stanno nel gruppo Synth, NON in fondo.
    "Unused" non e' letto da nessun chnget: finisce in Other.
    "Volume" e' letto anche in instr 2, ma il primo chnget e' sotto
    "@group Master": resta li'.
  - tocca l'intestazione di un gruppo per chiuderlo/aprirlo.

  SNAPSHOT (bottone macchina fotografica, a destra nella title bar):
  1. muovi qualche slider, Save Snapshot... -> "Bright"
  2. cambia i valori, Save Snapshot... -> "Dark"
  3. nel menu, sotto Recall, tocca Bright / Dark: tutti gli slider tornano
     ai valori salvati e il suono cambia
  4. Edit Snapshots... -> Overwrite / Rename / Delete; Cmd+Z annulla
  5. Save: gli snapshot sono nel .csd (blocco SNAPSHOTS nella sezione
     dei parametri in fondo al file); ricarica il file e ritrovali nel menu.
*/

sr     = 48000
ksmps  = 32
nchnls = 2
0dbfs  = 1

instr 1 ; synth + delay
  ; @group Synth
  kcut  chnget "Cutoff"
  iwave chnget "Wave"       ; menu: 1 Saw, 2 Square, 3 Triangle
  kgate chnget "Gate"       ; toggle
  kres  chnget "Resonance"

  ; @group Delay
  ktime chnget "DelayTime"
  kfb   chnget "Feedback"
  ksync chnget "Sync"       ; toggle: tempo fisso 0.25 s

  ; @group Master
  kvol  chnget "Volume"
  kmute chnget "Mute"

  ; oscillatore
  if iwave == 2 then
    asig vco2 0.3, 110, 10          ; square
  elseif iwave == 3 then
    asig vco2 0.3, 110, 12          ; triangle
  else
    asig vco2 0.3, 110              ; saw
  endif

  asig moogladder asig, port(kcut, 0.02), port(kres, 0.02)
  asig = asig * port(kgate, 0.01)

  ; delay
  ktd = (ksync == 1 ? 0.25 : ktime)
  abuf delayr 2
  adel deltapi port(ktd, 0.05)
  delayw asig + adel * kfb

  aout = asig + adel * 0.6
  aout = aout * port(kvol, 0.02) * (1 - kmute)
  outs aout, aout
endin

instr 2 ; legge Volume una seconda volta: il gruppo resta "Master"
  kvol chnget "Volume"
  kmute chnget "Mute"
  printk 2, kvol
endin

</CsInstruments>
<CsScore>
i1 0 3600
i2 0 3600
e
</CsScore>
</CsoundSynthesizer>
<apeCsoundParams>
<?xml version="1.0" encoding="UTF-8"?>

<APE_CSOUND_STATE>
  <CHANNEL_PARAM_SLOTS>
    <SLOT index="0" channel="Cutoff" min="100.0" max="8000.0" default="1200.0"
          skew="0.4" step="0.0"/>
    <SLOT index="1" channel="Resonance" min="0.0" max="0.9" default="0.3"
          skew="1.0" step="0.0"/>
    <SLOT index="2" channel="DelayTime" min="0.02" max="1.0" default="0.35"
          skew="1.0" step="0.0"/>
    <SLOT index="3" channel="Feedback" min="0.0" max="0.9" default="0.4"
          skew="1.0" step="0.0"/>
    <SLOT index="4" channel="Volume" min="0.0" max="1.0" default="0.7"
          skew="1.0" step="0.0"/>
    <SLOT index="5" channel="Unused" min="0.0" max="1.0" default="0.5"
          skew="1.0" step="0.0"/>
  </CHANNEL_PARAM_SLOTS>
  <INT_PARAM_SLOTS/>
  <BOOL_PARAM_SLOTS>
    <SLOT index="0" channel="Gate" default="1"/>
    <SLOT index="1" channel="Sync" default="0"/>
    <SLOT index="2" channel="Mute" default="0"/>
  </BOOL_PARAM_SLOTS>
  <CHOICE_PARAM_SLOTS>
    <SLOT index="0" channel="Wave" defaultIndex="0" options="Saw&#10;Square&#10;Triangle"/>
  </CHOICE_PARAM_SLOTS>
  <SNAPSHOTS>
    <SNAPSHOT name="Bright">
      <P channel="Cutoff" type="f" value="6000"/>
      <P channel="Resonance" type="f" value="0.2"/>
      <P channel="DelayTime" type="f" value="0.25"/>
      <P channel="Feedback" type="f" value="0.3"/>
      <P channel="Volume" type="f" value="0.7"/>
      <P channel="Unused" type="f" value="0.5"/>
      <P channel="Gate" type="b" value="1"/>
      <P channel="Sync" type="b" value="1"/>
      <P channel="Mute" type="b" value="0"/>
      <P channel="Wave" type="c" value="0"/>
    </SNAPSHOT>
    <SNAPSHOT name="Dark">
      <P channel="Cutoff" type="f" value="300"/>
      <P channel="Resonance" type="f" value="0.7"/>
      <P channel="DelayTime" type="f" value="0.6"/>
      <P channel="Feedback" type="f" value="0.75"/>
      <P channel="Volume" type="f" value="0.6"/>
      <P channel="Unused" type="f" value="0.5"/>
      <P channel="Gate" type="b" value="1"/>
      <P channel="Sync" type="b" value="0"/>
      <P channel="Mute" type="b" value="0"/>
      <P channel="Wave" type="c" value="2"/>
    </SNAPSHOT>
  </SNAPSHOTS>
</APE_CSOUND_STATE>

</apeCsoundParams>
