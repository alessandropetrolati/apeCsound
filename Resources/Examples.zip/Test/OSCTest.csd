<CsoundSynthesizer>
<CsInstruments>
ksmps = 64
nchnls = 2
0dbfs = 1

giOsc OSCinit 9002

instr 1   ; invia
  kmetro metro 1
  OSCsend kmetro, "127.0.0.1", 9002, "/test", "f", random:k(200, 800)
endin

instr 2   ; riceve e suona
  kfreq init 440
  kgot OSClisten giOsc, "/test", "f", kfreq
  printk2 kfreq
  aOut vco2 0.2, port(kfreq, 0.05)
  outs aOut, aOut
endin

schedule 1, 0, -1
schedule 2, 0, -1
</CsInstruments>
<CsScore>
</CsScore>
</CsoundSynthesizer>

<apeCsoundParams>
<?xml version="1.0" encoding="UTF-8"?>

<APE_CSOUND_STATE>
  <CHANNEL_PARAM_SLOTS/>
  <INT_PARAM_SLOTS/>
  <BOOL_PARAM_SLOTS/>
  <CHOICE_PARAM_SLOTS/>
</APE_CSOUND_STATE>

</apeCsoundParams>
