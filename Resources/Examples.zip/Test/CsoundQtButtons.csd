<CsoundSynthesizer>
<CsOptions>
</CsOptions>
<CsInstruments>

/*
  CsoundQtButtons - a CsoundQt file (widgets in <bsbPanel>) with every kind
  of CsoundQt button, to test the import into apeCsound.

  Load it in apeCsound (it has no <apeCsoundParams> block yet, so the
  CsoundQt widgets become parameters), press Apply, open Parameters:

  CsoundQt button                          -> apeCsound Button
  "Bell"   event, i 10 0 2                 -> Momentary, EVENT ON i 10 0 2
  "Held"   event, i 11.1 0 -1 (no latch)   -> Momentary, EVENT ON i 11.1 0 -1,
                                              EVENT OFF i -11.1 0 -1:
                                              sounds while you hold it
  "Drone"  event, i "Drone" 0 -1, latch    -> Toggle, EVENT ON i "Drone" 0 -1,
                                              EVENT OFF i "-Drone" 0 -1:
                                              press on, press off
  "hold"   value, no latch                 -> Momentary (noise while held)
  "mute"   value, latch                    -> Toggle (mutes the bell and held
                                              note)
  "gain"   knob                            -> Float slider 0..1

  The event buttons are named after their text ("Bell", "Held", "Drone");
  CsoundQt gives them generated names (b1001...). Open a Button (pencil) to
  see MODE, EVENT ON and EVENT OFF. In CsoundQt the same file works as
  before: the widgets are the same.
*/

sr     = 48000
ksmps  = 32
nchnls = 2
0dbfs  = 1

instr 1   ; always on: value buttons and the knob
  kgain  chnget "gain"
  khold  chnget "hold"        ; value button, no latch: 1 while pressed
  kh     port khold, 0.01
  anz    rand 0.12
  anz    butbp anz, 1500, 800
  anz    = anz * a(kh) * kgain
  outch 1, anz, 2, anz
endin

instr 10  ; "Bell" event button: i 10 0 2
  kmute  chnget "mute"
  kenv   expseg 1, p3, 0.001
  abell  = oscili(1, 660) + oscili(0.5, 660 * 2.76) + oscili(0.25, 660 * 5.4)
  abell  = abell * kenv * 0.12 * chnget:k("gain") * (1 - kmute)
  outch 1, abell, 2, abell
endin

instr 11  ; "Held" event button: i 11.1 0 -1 while pressed, i -11.1 0 -1 on release
  kmute  chnget "mute"
  kenv   madsr 0.02, 0.1, 0.8, 0.4
  anote  = vco2(0.08, 330) + vco2(0.06, 331.5)
  anote  moogladder anote, 2000, 0.2
  anote  = anote * kenv * chnget:k("gain") * (1 - kmute)
  outch 1, anote, 2, anote
endin

instr Drone  ; "Drone" event button (latch): on with i "Drone" 0 -1, off with i "-Drone" 0 -1
  kenv   madsr 0.5, 0.1, 1, 1.0
  adr    = vco2(0.06, 55) + vco2(0.05, 82.4) + vco2(0.04, 110.2)
  adr    moogladder adr, 600, 0.3
  adr    = adr * kenv * chnget:k("gain")
  outch 1, adr, 2, adr
endin

</CsInstruments>
<CsScore>
i1 0 z
e
</CsScore>
</CsoundSynthesizer>
<bsbPanel>
 <label>Widgets</label>
 <objectName/>
 <x>0</x>
 <y>0</y>
 <width>420</width>
 <height>260</height>
 <visible>true</visible>
 <uuid/>
 <bgcolor mode="background">
  <r>200</r>
  <g>210</g>
  <b>200</b>
 </bgcolor>
 <bsbObject version="2" type="BSBLabel">
  <objectName/>
  <x>10</x>
  <y>10</y>
  <width>300</width>
  <height>24</height>
  <uuid>{e5dd8cad-6cbf-49f4-96ab-f3aea6199244}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <label>CsoundQt buttons - import test</label>
  <alignment>left</alignment>
  <valignment>top</valignment>
  <font>Arial</font>
  <fontsize>11</fontsize>
  <precision>3</precision>
  <color>
   <r>0</r>
   <g>0</g>
   <b>0</b>
  </color>
  <bgcolor mode="nobackground">
   <r>255</r>
   <g>255</g>
   <b>255</b>
  </bgcolor>
  <bordermode>false</bordermode>
  <borderradius>1</borderradius>
  <borderwidth>0</borderwidth>
 </bsbObject>
 <bsbObject version="2" type="BSBLabel">
  <objectName/>
  <x>10</x>
  <y>45</y>
  <width>120</width>
  <height>20</height>
  <uuid>{3ba7d1c6-3e50-4ba2-8378-3ce1f7563e71}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <label>Event buttons</label>
  <alignment>left</alignment>
  <valignment>top</valignment>
  <font>Arial</font>
  <fontsize>11</fontsize>
  <precision>3</precision>
  <color>
   <r>0</r>
   <g>0</g>
   <b>0</b>
  </color>
  <bgcolor mode="nobackground">
   <r>255</r>
   <g>255</g>
   <b>255</b>
  </bgcolor>
  <bordermode>false</bordermode>
  <borderradius>1</borderradius>
  <borderwidth>0</borderwidth>
 </bsbObject>
 <bsbObject version="2" type="BSBButton">
  <objectName>b1001</objectName>
  <x>10</x>
  <y>70</y>
  <width>100</width>
  <height>30</height>
  <uuid>{6e85cb7e-6b3e-42d7-9fa5-5f0ccc42f6ca}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <type>event</type>
  <pressedValue>1.00000000</pressedValue>
  <stringvalue/>
  <text>Bell</text>
  <image>/</image>
  <eventLine>i 10 0 2</eventLine>
  <latch>false</latch>
  <momentaryMidiButton>false</momentaryMidiButton>
  <latched>false</latched>
  <fontsize>10</fontsize>
 </bsbObject>
 <bsbObject version="2" type="BSBButton">
  <objectName>b1002</objectName>
  <x>120</x>
  <y>70</y>
  <width>100</width>
  <height>30</height>
  <uuid>{a3821435-2d72-4c6a-a435-496386281bf3}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <type>event</type>
  <pressedValue>1.00000000</pressedValue>
  <stringvalue/>
  <text>Held</text>
  <image>/</image>
  <eventLine>i 11.1 0 -1</eventLine>
  <latch>false</latch>
  <momentaryMidiButton>false</momentaryMidiButton>
  <latched>false</latched>
  <fontsize>10</fontsize>
 </bsbObject>
 <bsbObject version="2" type="BSBButton">
  <objectName>b1003</objectName>
  <x>230</x>
  <y>70</y>
  <width>100</width>
  <height>30</height>
  <uuid>{bc72430e-234d-4c77-b689-ba8b15740016}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <type>event</type>
  <pressedValue>1.00000000</pressedValue>
  <stringvalue/>
  <text>Drone</text>
  <image>/</image>
  <eventLine>i "Drone" 0 -1</eventLine>
  <latch>true</latch>
  <momentaryMidiButton>false</momentaryMidiButton>
  <latched>false</latched>
  <fontsize>10</fontsize>
 </bsbObject>
 <bsbObject version="2" type="BSBLabel">
  <objectName/>
  <x>10</x>
  <y>115</y>
  <width>120</width>
  <height>20</height>
  <uuid>{f9b237c2-947b-4d18-a54b-60ebedc577d7}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <label>Value buttons</label>
  <alignment>left</alignment>
  <valignment>top</valignment>
  <font>Arial</font>
  <fontsize>11</fontsize>
  <precision>3</precision>
  <color>
   <r>0</r>
   <g>0</g>
   <b>0</b>
  </color>
  <bgcolor mode="nobackground">
   <r>255</r>
   <g>255</g>
   <b>255</b>
  </bgcolor>
  <bordermode>false</bordermode>
  <borderradius>1</borderradius>
  <borderwidth>0</borderwidth>
 </bsbObject>
 <bsbObject version="2" type="BSBButton">
  <objectName>hold</objectName>
  <x>10</x>
  <y>140</y>
  <width>100</width>
  <height>30</height>
  <uuid>{4d3d10a2-b5b4-4940-93ba-f2b288fb96b5}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <type>value</type>
  <pressedValue>1.00000000</pressedValue>
  <stringvalue/>
  <text>Hold (noise)</text>
  <image>/</image>
  <eventLine></eventLine>
  <latch>false</latch>
  <momentaryMidiButton>false</momentaryMidiButton>
  <latched>false</latched>
  <fontsize>10</fontsize>
 </bsbObject>
 <bsbObject version="2" type="BSBButton">
  <objectName>mute</objectName>
  <x>120</x>
  <y>140</y>
  <width>100</width>
  <height>30</height>
  <uuid>{0c5e8277-f06e-4cef-a6fe-28c4af583fb0}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <type>value</type>
  <pressedValue>1.00000000</pressedValue>
  <stringvalue/>
  <text>Mute</text>
  <image>/</image>
  <eventLine></eventLine>
  <latch>true</latch>
  <momentaryMidiButton>false</momentaryMidiButton>
  <latched>false</latched>
  <fontsize>10</fontsize>
 </bsbObject>
 <bsbObject version="2" type="BSBLabel">
  <objectName/>
  <x>250</x>
  <y>120</y>
  <width>60</width>
  <height>20</height>
  <uuid>{c3612bf5-0e0e-47d8-9ae3-a6e309960efa}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <label>Gain</label>
  <alignment>left</alignment>
  <valignment>top</valignment>
  <font>Arial</font>
  <fontsize>11</fontsize>
  <precision>3</precision>
  <color>
   <r>0</r>
   <g>0</g>
   <b>0</b>
  </color>
  <bgcolor mode="nobackground">
   <r>255</r>
   <g>255</g>
   <b>255</b>
  </bgcolor>
  <bordermode>false</bordermode>
  <borderradius>1</borderradius>
  <borderwidth>0</borderwidth>
 </bsbObject>
 <bsbObject version="2" type="BSBKnob">
  <objectName>gain</objectName>
  <x>250</x>
  <y>140</y>
  <width>60</width>
  <height>60</height>
  <uuid>{aee4d601-5cc1-4ceb-84dd-e03d05f76834}</uuid>
  <visible>true</visible>
  <midichan>0</midichan>
  <midicc>-3</midicc>
  <description/>
  <minimum>0</minimum>
  <maximum>1</maximum>
  <value>0.7</value>
  <mode>lin</mode>
  <mouseControl act="jump">continuous</mouseControl>
  <resolution>0.01000000</resolution>
  <randomizable group="0">false</randomizable>
 </bsbObject>
</bsbPanel>
<bsbPresets>
</bsbPresets>
