<CsoundSynthesizer>
<CsOptions>
; -d is here on purpose: apeCsound must show the graphs anyway
-d
</CsOptions>
<CsInstruments>
; GraphsTest.csd - test for the apeCsound "Graphs" panel (main menu > Graphs)
;
; What you should see:
;   ftable 1    sine (GEN10)                          bipolar, smooth line
;   ftable 2    sawtooth, 8 harmonics (GEN10)         bipolar
;   ftable 3    square (GEN7)                         bipolar, vertical edges
;   ftable 4    ADSR-like envelope (GEN7)             positive only (baseline at the bottom)
;   ftable 5    exponential decay (GEN5)              positive only
;   ftable 6    Hanning window (GEN20)                positive only
;   ftable 7    gaussian noise, 65536 points (GEN21) long table -> min/max band
;   ftable 8    negative ramp (GEN7)                  negative only (baseline at the top)
;   ftable 100  random harmonics, regenerated every 2 s by instr 2:
;               the SAME tile must change shape (no new tiles)
;
;   instr 1  aOut      waveform (display), refreshed every 50 ms
;   instr 1  aOut fft  spectrum (dispfft, 2048 points, dB): a sawtooth whose
;                      pitch sweeps slowly up and down through a filter
;   instr 3  kLfo      slow control signal (display over 2 s)
;
; display/dispfft are drawn only while the Graphs panel is open.
; Every Apply clears the panel and rebuilds it.

sr     = 48000
ksmps  = 64
nchnls = 2
0dbfs  = 1

; ---------------------------------------------------------------- ftables
giSine   ftgen 1, 0, 4096,   10, 1
giSaw    ftgen 2, 0, 4096,   10, 1, 1/2, 1/3, 1/4, 1/5, 1/6, 1/7, 1/8
giSquare ftgen 3, 0, 4096,    7, 1, 2048, 1, 0, -1, 2048, -1
giEnv    ftgen 4, 0, 1024,    7, 0, 64, 1, 128, 0.6, 640, 0.6, 192, 0
giDecay  ftgen 5, 0, 1024,    5, 1, 1024, 0.001
giWin    ftgen 6, 0, 2048,   20, 2, 1
giNoise  ftgen 7, 0, 65536,  21, 6
giNeg    ftgen 8, 0, 1024,    7, 0, 1024, -1

; ---------------------------------------------------------------- signals
instr 1
  ; pitch sweeping 55 -> 880 Hz and back every 8 s
  kPitch = 55 * 2 ^ (4 * (0.5 - 0.5 * cos(2 * $M_PI * phasor:k(1/8))))
  aSaw   vco2 0.3, kPitch
  aOut   moogladder aSaw, 3000, 0.3

  display aOut, 0.05                ; waveform, 50 ms window
  dispfft aOut, 0.1, 2048, 1, 1     ; spectrum: 2048 points, Hanning, dB

  aEnv linseg 0, 0.5, 1             ; fade-in
  outs aOut * aEnv * 0.5, aOut * aEnv * 0.5
endin

; ftable 100 regenerated every 2 s with random harmonic amplitudes
instr 2
  iH1 random 0, 1
  iH2 random 0, 1
  iH3 random 0, 1
  iH4 random 0, 1
  iH5 random 0, 1
  iH6 random 0, 1
  iTab ftgen 100, 0, 2048, 10, iH1, iH2, iH3, iH4, iH5, iH6
  schedule 2, 2, 0.1
endin

; slow control signal
instr 3
  kLfo lfo 1, 0.5, 0                ; sine LFO, 0.5 Hz
  display kLfo, 2
endin

schedule 1, 0, -1
schedule 2, 0, 0.1
schedule 3, 0, -1

</CsInstruments>
<CsScore>
</CsScore>
</CsoundSynthesizer>
