<CsoundSynthesizer>
<CsOptions>
</CsOptions>
<CsInstruments>

/*
  ButtonTest - every way to use a Button parameter, once, explained.

  A Button is a parameter (the DAW sees it, automates it, MIDI-learns it)
  with a MODE:
    Toggle      a switch: press = ON, press again = OFF. INIT says how it
                starts (Off / On).
    Momentary   ON only while you hold it, OFF when you release it.
  and two optional score lines that apeCsound sends for you:
    EVENT ON    when the button goes from 0 to 1 (press / switch on), like
                a CsoundQt event button
    EVENT OFF   when it goes from 1 to 0 (release / switch off) - e.g. to
                stop the held note started by EVENT ON

  Open the configuration of a button (pencil) to see MODE, INIT, EVENT ON
  and EVENT OFF. Press Apply, then try the buttons in the Parameters panel,
  group by group:

    TOGGLE
      1  Drone    Toggle, INIT Off: a drone while it is ON
      2  Bright   Toggle, INIT On: the drone filter open (ON) or closed (OFF)

    MOMENTARY
      3  Hold     Momentary: noise only while you hold the button

    EVENT LINES - apeCsound sends the score lines, no code (style CsoundQt)
      4  Bell     Momentary, EVENT ON "i 10 0 2": a bell at each press
      5  Pad      Momentary, EVENT ON "i 14.1 0 -1" (a held note) and
                  EVENT OFF "i -14.1 0 0": it sounds as long as you hold it,
                  like a key, with a soft release when you let go

    EVENTS FROM THE CODE - the code reacts to the button (style Cabbage,
    card menu ... > Copy Trigger Code)
      6  Chord    Momentary: three notes at each press (trigger, rising edge)
      7  Arp      Toggle: an arpeggio starts when it goes ON and stops when it
                  goes OFF (trigger on both edges, a held note i 12.1 0 -1)

    MONITOR
      Status      what is sounding: bells, pad, chord notes, arpeggio

  Things to notice:
    - Each press starts ONE event, also with DAW automation (which sends the
      value at every audio block): events fire on the edges, 0 -> 1 (ON) and
      1 -> 0 (OFF).
    - Record the buttons as automation in your DAW and play it back: Hold
      and Pad sound as long as you held them, Bell and Chord fire at each
      press.
    - Randomize All does not touch Momentary buttons (Hold, Bell, Pad,
      Chord) nor buttons with EVENT lines; snapshots do not store Momentary
      buttons.
    - Use EVENT lines OR code for a button, not both: Chord with an EVENT ON
      line would start twice.
    - A held note (negative duration) needs its OFF line, or it keeps
      sounding: the fractional number (14.1) makes "i -14.1" stop exactly
      that note.
    - Bell and Pad are read with chnget below only to place their cards in
      the "Event lines" group: the code does nothing with them.
*/

sr     = 48000
ksmps  = 32
nchnls = 2
0dbfs  = 1

instr 1   ; always on: reads the buttons and makes the continuous sounds

  kgain  chnget "Gain"

  ; @group Toggle
  kDrone  chnget "Drone"     ; 1 Toggle, INIT Off
  kBright chnget "Bright"    ; 2 Toggle, INIT On

  ; @group Momentary
  kHold   chnget "Hold"      ; 3 Momentary

  ; @group Event lines
  ; 4 and 5: their EVENT lines do the work. Read here only so that their
  ; cards sit in this group (a group collects the channels read below it).
  kBell   chnget "Bell"      ; 4 Momentary, EVENT ON  i 10 0 2
  kPad    chnget "Pad"       ; 5 Momentary, EVENT ON  i 14.1 0 -1, OFF i -14.1 0 0

  ; @group Events from the code
  kChord  chnget "Chord"     ; 6 Momentary, trigger in the code
  kArp    chnget "Arp"       ; 7 Toggle, start/stop in the code

  ; @group

  ; --- 1 + 2: a drone, filter open or closed ------------------------------
  kdr    port kDrone, 0.08
  adr    = vco2(0.12, 55) + vco2(0.08, 82.5) + vco2(0.06, 110.3)
  kcut   = (kBright == 1 ? 2800 : 350)
  kcut   port kcut, 0.1
  adr    moogladder adr, kcut, 0.25
  adr    = adr * a(kdr)

  ; --- 3: noise only while Hold is pressed --------------------------------
  kh     port kHold, 0.01
  anz    rand 0.15
  anz    butbp anz, 1200, 600
  anz    = anz * a(kh)

  ; --- 6: Chord - the code reacts to the press (0 -> 1, once per press) ---
  if trigger:k(kChord, 0.5, 0) == 1 then
    event "i", 11, 0, 1.5, 60
    event "i", 11, 0, 1.5, 64
    event "i", 11, 0, 1.5, 67
  endif

  ; --- 7: Arp - ON starts a held instrument, OFF stops it -----------------
  if trigger:k(kArp, 0.5, 0) == 1 then
    event "i", 12.1, 0, -1          ; held (negative duration)
  endif
  if trigger:k(kArp, 0.5, 1) == 1 then
    event "i", -12.1, 0, 0          ; release the held instance
  endif

  ; --- Monitor: what is sounding ------------------------------------------
  if metro(8) == 1 then
    if kArp == 1 then
      Sarp strcpyk "on"
    else
      Sarp strcpyk "off"
    endif
    Sst sprintfk "bells %d   pad %d   chord notes %d   arp %s", active:k(10), active:k(14), active:k(11), Sarp
    chnset Sst, "Status"
  endif

  amix   = (adr + anz) * kgain
  outch 1, amix, 2, amix
endin

instr 10  ; 4 Bell - started by the EVENT ON line of the "Bell" button
  kenv   expseg 1, p3, 0.001
  icps   = 660
  abell  = oscili(1, icps) + oscili(0.5, icps * 2.76) + oscili(0.25, icps * 5.4) + oscili(0.12, icps * 8.93)
  abell  = abell * kenv * 0.12 * chnget:k("Gain")
  outch 1, abell, 2, abell
endin

instr 11  ; 6 Chord note (p4 = MIDI note)
  kenv   linseg 0, 0.01, 1, p3 - 0.31, 0.6, 0.3, 0
  anote  vco2 0.08, cpsmidinn(p4)
  anote  moogladder anote, 1800, 0.2
  anote  = anote * kenv * chnget:k("Gain")
  outch 1, anote, 2, anote
endin

instr 12  ; 7 Arpeggio - held until the Arp button goes OFF
  knotes[] fillarray 72, 76, 79, 84, 79, 76
  kstep  init 0
  if metro(8) == 1 then
    event "i", 13, 0, 0.12, knotes[kstep % 6]
    kstep += 1
  endif
endin

instr 13  ; 7 one arpeggio note
  kenv   expseg 1, p3, 0.01
  anote  = oscili(0.1, cpsmidinn(p4)) * kenv * chnget:k("Gain")
  outch 1, anote, 2, anote
endin

instr 14  ; 5 Pad - a held note (EVENT ON i 14.1 0 -1) until EVENT OFF (i -14.1 0 0)
  kenv   madsr 0.05, 0.2, 0.7, 0.6     ; 0.6 s of release after the OFF
  apad   = vco2(0.06, 220) + vco2(0.06, 220.7) + vco2(0.05, 329.6)
  apad   moogladder apad, 1500, 0.15
  apad   = apad * kenv * chnget:k("Gain")
  outch 1, apad, 2, apad
endin

</CsInstruments>
<CsScore>
i1 0 z
e
</CsScore>
</CsoundSynthesizer>
<apeCsoundParams>
<?xml version="1.0" encoding="UTF-8"?>

<APE_CSOUND_STATE>
  <CHANNEL_PARAM_SLOTS>
    <SLOT index="0" channel="Gain" min="0.0" max="1.0" default="0.7"
          skew="1.0" step="0.0"/>
  </CHANNEL_PARAM_SLOTS>
  <INT_PARAM_SLOTS/>
  <BOOL_PARAM_SLOTS>
    <SLOT index="0" channel="Drone" default="0"/>
    <SLOT index="1" channel="Bright" default="1"/>
    <SLOT index="2" channel="Hold" default="0" momentary="1"/>
    <SLOT index="3" channel="Bell" default="0" momentary="1" event="i 10 0 2"/>
    <SLOT index="4" channel="Pad" default="0" momentary="1" event="i 14.1 0 -1" eventOff="i -14.1 0 0"/>
    <SLOT index="5" channel="Chord" default="0" momentary="1"/>
    <SLOT index="6" channel="Arp" default="0"/>
  </BOOL_PARAM_SLOTS>
  <CHOICE_PARAM_SLOTS/>
</APE_CSOUND_STATE>

</apeCsoundParams>
