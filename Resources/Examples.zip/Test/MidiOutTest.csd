<CsoundSynthesizer>
<CsOptions>
</CsOptions>
<CsInstruments>

/*
  MidiOutTest - does MIDI OUT reach the host?

  Every beat (Tempo, default 120 BPM) the patch sends a MIDI note on channel
  1 (C4..B4 cycling) with midiout, plus a CC 1 ramp (0..127) via outkc, and
  prints "MIDI out: note N" in the console. Nothing is audible by itself:
  put a synth AFTER apeCsound in the same FX chain (Reaper: ReaSynth) or
  route the track's MIDI output to another track. The Monitor group shows
  "LastNote" and "CC1".

  MIDI IN check: any note received is echoed to the console ("MIDI in: ...")
  and shown in Monitor as "InNote" / "InVel".
*/

sr     = 48000
ksmps  = 32
nchnls = 2
0dbfs  = 1

instr 1
  ktempo chnget "Tempo"
  ktempo = (ktempo < 20 ? 120 : ktempo)
  ktick  metro ktempo / 60
  kstep  init 0
  knote  init 60

  if ktick == 1 then
    knote = 60 + (kstep % 12)
    midiout 144, 1, knote, 100          ; note on, channel 1
    printks "MIDI out: note %d\n", 0, knote
    chnset knote, "LastNote"
    kstep += 1
  endif
  ; note off half a beat later
  koff delayk ktick, 30 / ktempo
  if koff == 1 then
    midiout 128, 1, knote, 0
  endif

  ; CC 1 ramp, 0..127 over 4 seconds
  kcc = int(phasor:k(0.25) * 127)
  outkc 1, 1, kcc, 0, 127
  chnset kcc, "CC1"

  ; MIDI in echo
  kstatus, kchan, kdata1, kdata2 midiin
  if kstatus == 144 && kdata2 > 0 then
    printks "MIDI in: note %d vel %d ch %d\n", 0, kdata1, kdata2, kchan
    chnset kdata1, "InNote"
    chnset kdata2, "InVel"
  endif
endin

</CsInstruments>
<CsScore>
i1 0 z
e
</CsScore>
</CsoundSynthesizer>
<apeCsoundParams>
<?xml version="1.0" encoding="UTF-8"?>

<APE_CSOUND_STATE>
  <CHANNEL_PARAM_SLOTS>
    <SLOT index="0" channel="Tempo" min="20.0" max="300.0" default="120.0" skew="1.0" step="1.0"/>
  </CHANNEL_PARAM_SLOTS>
  <INT_PARAM_SLOTS/>
  <BOOL_PARAM_SLOTS/>
  <CHOICE_PARAM_SLOTS/>
</APE_CSOUND_STATE>

</apeCsoundParams>
