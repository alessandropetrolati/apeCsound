<CsoundSynthesizer>
<CsOptions>
</CsOptions>
<CsInstruments>
; ChnsetTest.csd - chnset on channels mapped to apeCsound parameters
;
; Expected:
;   Cutoff (Float)  : the slider moves by itself (slow LFO written by Csound
;                     with chnset every k-cycle); the filter follows it.
;   Steps  (Int)    : counts 1..8, one step per second.
;   Gate   (Bool)   : toggles every 2 seconds (sound on/off).
;   Wave   (Choice) : cycles Saw -> Square -> Triangle every 3 seconds.
;
; Press "Auto" (toggle) OFF to stop Csound writing: then the four controls
; must respond to the mouse / DAW automation again.

sr     = 48000
ksmps  = 64
nchnls = 2
0dbfs  = 1

instr 1
  kAuto chnget "Auto"

  if kAuto == 1 then
    ; Csound -> parameters
    kLfo   lfo 1, 0.1, 0
    chnset 200 + 1800 * (0.5 + 0.5 * kLfo), "Cutoff"
    chnset 1 + int(times:k() % 8), "Steps"
    chnset int(times:k() / 2) % 2, "Gate"
    chnset 1 + int(times:k() / 3) % 3, "Wave"
  endif

  ; parameters -> sound
  kCutoff chnget "Cutoff"
  kSteps  chnget "Steps"
  kGate   chnget "Gate"
  kWave   chnget "Wave"

  kFreq = 110 * kSteps / 2 + 110
  kMode = (kWave == 2 ? 2 : (kWave == 3 ? 12 : 0))   ; vco2: 0 saw, 2 square, 12 triangle
  aOsc  vco2 0.3, kFreq;, kMode
    
  aFil  moogladder aOsc, port(kCutoff, 0.02), 0.4
  aOut  = aFil * port(kGate, 0.01)
  outs aOut, aOut
endin

schedule 1, 0, -1

</CsInstruments>
<CsScore>
</CsScore>
</CsoundSynthesizer>

<apeCsoundParams>
<?xml version="1.0" encoding="UTF-8"?>

<APE_CSOUND_STATE>
  <CHANNEL_PARAM_SLOTS>
    <SLOT index="0" channel="Cutoff" min="200.0" max="2000.0" default="1000.0"
          skew="1.0" step="0.0"/>
  </CHANNEL_PARAM_SLOTS>
  <INT_PARAM_SLOTS>
    <SLOT index="0" channel="Steps" min="1" max="8" default="1"/>
  </INT_PARAM_SLOTS>
  <BOOL_PARAM_SLOTS>
    <SLOT index="0" channel="Gate" default="1"/>
    <SLOT index="1" channel="Auto" default="1"/>
  </BOOL_PARAM_SLOTS>
  <CHOICE_PARAM_SLOTS>
    <SLOT index="0" channel="Wave" defaultIndex="0" options="Saw&#10;Square&#10;Triangle"/>
  </CHOICE_PARAM_SLOTS>
</APE_CSOUND_STATE>

</apeCsoundParams>
