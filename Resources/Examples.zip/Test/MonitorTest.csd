<CsoundSynthesizer>
<CsOptions>
</CsOptions>
<CsInstruments>

/*
  MonitorTest - every kind of Monitor card, once, explained.

  WHAT IS THE MONITOR
    The grey group at the bottom of the Parameters panel: every channel the
    code WRITES with chnset and that is not a parameter. You never choose
    the look - apeCsound reads it from the channel itself:
      TYPE    k number -> bar / dial / lamp / steps, S string -> text,
              a audio -> level meter in dB with a CLIP lamp
      RANGE   declared with chn_k -> level bar; none -> track that adapts
              to the values seen; a range through zero -> dial with needle
      VALUES  only 0 and 1 -> lamp; only whole numbers in a whole range
              -> steps (one cell per value)
      NAME    Base1, Base2... or Base_L / Base_R -> one card for all
    The only attribute is "spark" (a sparkline), 11th argument of chn_k.

  HOW TO USE THIS FILE
    Press Apply and open the Parameters panel. The patch plays an 8-step
    melody (no input needed) with rests: a pattern says which steps play,
    a new pattern every bar (4 patterns, A..D). Steps 1 and 5 are accented.
    Each numbered block of code writes ONE kind of card; the numbers are the
    order of the cards in the panel. Keep the Gain slider around 0.7.

    SYNTH GROUP (written below "; @group Synth": next to the Gain slider)
      1  Envelope   LEVEL BAR, range 0..1 from chn_k: solid fill, ruler,
                    min/max; empty on the rests
      2  Gate       LAMP: only 0 and 1 - ON for the first half of a note
      3  Drift      TRACK, no range: a ring on a dashed line between the
                    min/max seen so far (in italics, with arrows)
      4  Pitch      SPARKLINE (chn_k "spark"): the melody over the last 5 s
      5  Step       STEPS, range 0..7, whole numbers only: 8 cells, the
                    current one lit = WHERE the sequencer is; "3 / 7"
      6  Note       TEXT built with sprintfk: "E4  120 BPM  A"

    MONITOR GROUP (bottom of the panel)
      7  Harm       MULTI-BAR: Harm1..Harm4, same prefix + index -> one card
      8  Voice      AUDIO METER: green/yellow/red segments, peak line, CLIP
      9  Pan        DIAL, range -1..1 through zero: needle, zero at the top,
                    negative to the left in blue
     10  Out        STEREO PAIR: Out_L / Out_R -> one card, meters L and R
     11  Light      ROW OF LAMPS: Light1..Light8 = WHICH steps play in this
                    bar (several on at once). Compare with Step (5): one
                    position vs eight switches. CREATED AT RUN TIME: the
                    card appears 3 s after Apply (instr 2, see block 11).

    NOT SHOWN, on purpose (block 0)
      Gain          a parameter: chnset on it would move its slider
      HOST_BPM      host channels are read, never shown
      Status_ident  "visible(1)" is a Cabbage GUI message: ignored

  TRY THIS
    - Hover a card: what it is and why it looks like that.
    - Right-click a card (touch and hold on iOS): Copy chn_k Declaration
      copies a ready-made chn_k line - on Drift it turns the track into a
      level bar once pasted at the top. Reset Observed Range is also a
      double-click.
    - Voice: write "asig * 4" in its chnset (block 8) and Apply: CLIP lights
      and stays on until you click the card.
    - Rename "Light1" in block 11 to "Lite1" and Apply: Light1 is gone, and
      "Lite1" (alone, no index partner) shows as its own card.
    - Replace the chnset of Gate (block 2) with  chnset 0, "Gate"  and
      Apply: after two seconds the card dims and says "no change since
      Apply" - what a channel the code never really writes looks like.

  Two Csound facts this file takes into account:
    - chnset creates its channel at INIT time, even inside an "if" that is
      false: to make a channel appear later, start an instrument later
      (block 11, instr 2).
    - A channel name built with sprintfk and an expression ("Light%d",
      kl + 1) is wrong at init, because the expression is only computed at
      k-time: Csound creates a ghost channel ("Light0") stuck at 0. Use
      literal names (block 11).

  Lamps and steps are recognised from the values: for about a second after
  Apply they show as a plain bar, then switch.

  Parameters menu (+) > Channels... (Cmd+4) lists every channel with its
  origin. MonitorStressTest.csd is the same at scale.
*/

sr     = 48000
ksmps  = 32
nchnls = 2
0dbfs  = 1

; ---------------------------------------------------------------------------
; Ranges. Only channels that need a RANGE (or "spark") are declared; all the
; others are created by their first chnset.
;
;   chn_k  name, mode, itype, default, min, max, x, y, w, h, "attributes"
;     mode 2  = output (written by the code)
;     itype 2 = linear range (with itype 0 Csound drops range AND attribute)
;     x, y, w, h: CsoundQt/Cabbage geometry, unused by apeCsound
; ---------------------------------------------------------------------------
chn_k "Envelope", 2, 2, 0,   0,   1                          ; block 1
chn_k "Pitch",    2, 2, 220, 110, 880, 0, 0, 0, 0, "spark"   ; block 4
chn_k "Step",     2, 2, 0,   0,   7                          ; block 5
chn_k "Pan",      2, 2, 0,  -1,   1                          ; block 9

giScale[] fillarray 0, 2, 4, 5, 7, 9, 11, 12
gSNames[] fillarray "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"
; four rhythm patterns, 8 steps each: 1 = the step plays, 0 = rest
giPat[]   fillarray 1,1,1,1,1,1,1,1,  1,0,1,1,1,0,1,0,  1,1,0,1,1,1,0,1,  1,0,0,1,1,0,1,1
gSPat[]   fillarray "A", "B", "C", "D"
gkpat     init 0                       ; current pattern, shared with instr 2

instr 1

  ; Everything read or written below this line, up to "; @group" (or endin),
  ; goes in the "Synth" group: the Gain slider and cards 1..6, in the order
  ; of the code.
  ; @group Synth

  ; ===== 0. NOT SHOWN: a parameter and a host channel, only read ==========
  kgain  chnget "Gain"                 ; parameter (Float 0..1): a slider
  kbpm   chnget "HOST_BPM"             ; host tempo (120 in the standalone app)
  kbpm   = (kbpm > 0 ? kbpm : 120)

  ; --- the sequencer: 8 eighth notes at the host tempo ---------------------
  ktick  metro kbpm / 60 * 2
  kstep  init 7
  knote  init 60
  kpat   init 3
  if ktick == 1 then
    kstep = (kstep + 1) % 8
    if kstep == 0 then
      kpat = (kpat + 1) % 4            ; a new pattern every bar
    endif
    knote = 60 + giScale[kstep]
    chnset "visible(1)", "Status_ident"  ; 0: Cabbage GUI message, ignored
  endif
  kon    = giPat[kpat * 8 + kstep]     ; 1 = this step plays, 0 = rest
  kacc   = (kstep % 4 == 0 ? 2 : 1)    ; accent on steps 1 and 5
  gkpat  = kpat                        ; for instr 2 (block 11)

  ; ===== 1. LEVEL BAR - chn_k "Envelope" 0..1 (declared range) ============
  ; Solid fill from the left, a ruler and the declared min/max underneath.
  ; It drops from full to empty on every note, and stays empty on the rests.
  kenv   = 1 - phasor:k(kbpm / 60 * 2)
  kenv   = kenv * kenv * kon
  chnset kenv, "Envelope"

  ; ===== 2. LAMP - a channel that is only ever 0 or 1 =====================
  ; No declaration, no attribute: after a second it becomes a lamp.
  ; ON for the first half of each note, OFF on the rests.
  chnset (kenv > 0.25 ? 1 : 0), "Gate"

  ; ===== 3. TRACK - no chn_k, so no range =================================
  ; A slow random detune in cents, 2..20 (always positive: a range through
  ; zero would make it a dial, and that is Pan's job). A ring slides on a
  ; dashed line between the lowest and highest values seen so far.
  kdrift rspline 2, 20, 0.2, 0.6
  chnset kdrift, "Drift"

  ; ===== 4. SPARKLINE - chn_k ... "spark" ==================================
  ; The pitch in Hz, smoothed: the curve draws the melody, glides included.
  kcps   portk cpsmidinn(knote) * cent(kdrift), 0.03
  chnset kcps, "Pitch"

  ; ===== 5. STEPS - chn_k "Step" 0..7, only whole numbers written =========
  ; A range with whole ends (3 to 33 values) that only receives whole
  ; numbers: a row of cells, one per value - the position of a sequencer.
  ; Write a fractional value once and it is a level bar for good.
  chnset kstep, "Step"

  ; ===== 6. TEXT - a string channel, formatted with sprintfk ==============
  ; One line of state: note (or "rest"), tempo, pattern letter. Units,
  ; decimals, anything: build the string, the card shows it as it is.
  if ktick == 1 then
    if kon == 1 then
      Snote sprintfk "%s%d", gSNames[knote % 12], int(knote / 12) - 1
    else
      Snote strcpyk "rest"
    endif
    Sline sprintfk "%s  %.0f BPM  %s", Snote, kbpm, gSPat[kpat]
    chnset Sline, "Note"
  endif

  ; End of the Synth group: the cards below go to the Monitor group.
  ; @group

  ; ===== 7. MULTI-BAR - Harm1..Harm4 =======================================
  ; Four partials whose amplitudes move slowly: same prefix + index, so one
  ; card with four vertical bars.
  kh1    = 0.6 + 0.4 * oscil:k(1, 0.11)
  kh2    = 0.5 + 0.5 * oscil:k(1, 0.17, -1, 0.25)
  kh3    = 0.4 + 0.4 * oscil:k(1, 0.23, -1, 0.5)
  kh4    = 0.3 + 0.3 * oscil:k(1, 0.31, -1, 0.75)
  chnset kh1, "Harm1"
  chnset kh2, "Harm2"
  chnset kh3, "Harm3"
  chnset kh4, "Harm4"

  ; ===== 8. AUDIO METER - chnset on an a-rate signal ======================
  ; The voice before panning. Segmented meter in dB (-60..0): rises at once,
  ; falls slowly, a thin peak line held for a second. The CLIP lamp on the
  ; right stays dark (the voice never reaches 0 dBFS): try "asig * 4" here.
  asig   = poscil(kh1, kcps) + poscil(kh2, kcps * 2) + poscil(kh3, kcps * 3) + poscil(kh4, kcps * 4)
  asig   = asig * a(kenv * kacc) * 0.12 * kgain
  chnset asig, "Voice"

  ; ===== 9. DIAL - chn_k "Pan" -1..1, a range through zero =================
  ; A slow auto-pan: -1 = left, +1 = right. Half-moon dial with a needle,
  ; zero at the top, blue to the left, teal to the right.
  kpan   = 0.5 + 0.4 * oscil:k(1, 0.25)
  chnset (kpan - 0.5) * 2.5, "Pan"
  aL     = asig * sqrt(1 - kpan)
  aR     = asig * sqrt(kpan)
  outch 1, aL, 2, aR

  ; ===== 10. STEREO PAIR - Out_L, Out_R ====================================
  ; Two audio channels named as a left/right pair (_L/_R, L/R, Left/Right):
  ; one card, two meters labelled L and R. They swap as the Pan dial moves.
  chnset aL, "Out_L"
  chnset aR, "Out_R"
endin

; ===== 11. ROW OF LAMPS, CREATED AT RUN TIME - Light1..Light8 ==============
; Same prefix + index -> one card; values 0/1 -> lamps instead of bars. Each
; lamp says whether that step PLAYS in the current pattern: several are on
; at once, and they change every bar (Step, block 5, is the position).
; The score starts this instrument 3 seconds after Apply: before that the
; Light channels do not exist, then the card appears by itself, without
; pressing Apply again (a chnset in instr 1, even inside a false "if", would
; create the channels at once). Literal names on purpose: see "Light0" at
; the top.
instr 2
  kpat   = gkpat
  chnset giPat[kpat * 8 + 0], "Light1"
  chnset giPat[kpat * 8 + 1], "Light2"
  chnset giPat[kpat * 8 + 2], "Light3"
  chnset giPat[kpat * 8 + 3], "Light4"
  chnset giPat[kpat * 8 + 4], "Light5"
  chnset giPat[kpat * 8 + 5], "Light6"
  chnset giPat[kpat * 8 + 6], "Light7"
  chnset giPat[kpat * 8 + 7], "Light8"
endin

</CsInstruments>
<CsScore>
i1 0 z
i2 3 z
e
</CsScore>
</CsoundSynthesizer>
<apeCsoundParams>
<?xml version="1.0" encoding="UTF-8"?>

<APE_CSOUND_STATE>
  <CHANNEL_PARAM_SLOTS>
    <SLOT index="0" channel="Gain" min="0.0" max="1.0" default="0.7"
          skew="1.0" step="0.0"/>
  </CHANNEL_PARAM_SLOTS>
  <INT_PARAM_SLOTS/>
  <BOOL_PARAM_SLOTS/>
  <CHOICE_PARAM_SLOTS/>
</APE_CSOUND_STATE>

</apeCsoundParams>
