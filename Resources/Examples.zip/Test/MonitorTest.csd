<CsoundSynthesizer>
<CsOptions>
</CsOptions>
<CsInstruments>

/*
  MonitorTest - the "Monitor" group of the Parameters panel.

  Channels written by the code with chnset, that are not parameters, are
  shown read-only at the bottom of the panel (this is where CsoundQt's
  outvalue / Cabbage meters end up).

  After Apply the panel must show a "Monitor" group with:
    Level      - input RMS in dB, bar from -60 to 0 (hints from chn_k)
    Peak       - peak of the input, bar 0..1 (hints from chn_k)
    LFO        - a slow sine, bar adapts to the min/max seen so far
    Beat       - counts the host beats (needs a DAW transport)
    Status     - a STRING channel: "playing" / "stopped"
    Late       - created at run time after 5 seconds: it appears by itself

  Send some audio into the track to see Level and Peak move.
  "Gain" is a normal parameter: it is NOT in Monitor even if the code
  writes it back (chnset moves the slider instead).
*/

sr     = 48000
ksmps  = 32
nchnls = 2
0dbfs  = 1

; output channels declared with range hints (itype 2 = linear): the bar
; uses them; arguments: name, mode (2 = output), itype, default, min, max
chn_k "Level", 2, 2, -60, -60, 0
chn_k "Peak",  2, 2, 0, 0, 1

instr 1
  kgain  chnget "Gain"
  aL     inch 1
  aR     inch 2
  ain    = (aL + aR) * 0.5 * kgain

  krms   rms ain
  kdb    = (krms > 0.000001 ? dbamp(krms) : -60)
  chnset limit(kdb, -60, 0), "Level"

  kpk    max_k ain, metro(10), 1
  chnset kpk, "Peak"

  klfo   oscil 1, 0.2
  chnset klfo, "LFO"

  kplay  chnget "IS_PLAYING"
  kppq   chnget "HOST_PPQ_POS"
  chnset floor(kppq), "Beat"
  if changed(kplay) == 1 || timeinstk() == 1 then
    Sstat = (kplay == 1 ? "playing" : "stopped")
    chnset Sstat, "Status"
  endif

  ; a channel that only exists after 5 s: shows up in Monitor when written
  if timeinsts() > 5 then
    chnset timeinsts(), "Late"
  endif

  ; writing back a parameter: moves its slider, does not go to Monitor
  if metro(0.5) == 1 && kgain < 0.5 then
    chnset 0.5, "Gain"
  endif

  outch 1, aL * kgain, 2, aR * kgain
endin

</CsInstruments>
<CsScore>
i1 0 z
e
</CsScore>
</CsoundSynthesizer>
<apeCsoundParams>
<?xml version="1.0" encoding="UTF-8"?>

<APE_CSOUND_STATE>
  <CHANNEL_PARAM_SLOTS>
    <SLOT index="0" channel="Gain" min="0.0" max="1.0" default="1.0"
          skew="1.0" step="0.0"/>
  </CHANNEL_PARAM_SLOTS>
  <INT_PARAM_SLOTS/>
  <BOOL_PARAM_SLOTS/>
  <CHOICE_PARAM_SLOTS/>
</APE_CSOUND_STATE>

</apeCsoundParams>
