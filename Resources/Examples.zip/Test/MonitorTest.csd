<CsoundSynthesizer>
<CsOptions>
</CsOptions>
<CsInstruments>

/*
  MonitorTest - every kind of Monitor display, once, explained.

  WHAT IS THE MONITOR
    The grey group at the bottom of the Parameters panel. It shows
    every channel the code WRITES with chnset that is not a parameter. You
    never choose the look: apeCsound decides it from the channel itself -
      - its TYPE        k number -> bar, S string -> text, a audio -> meter
      - its RANGE       declared with chn_k -> fixed bar; none -> adaptive;
                        a range that crosses zero -> bipolar bar
      - its VALUES      only 0 and 1 -> lamp (after about a second)
      - its NAME        Base1, Base2... -> one card with a bar per channel
    The only attribute is "spark" (a sparkline), in the 11th argument of
    chn_k. Every card has a small icon of its kind next to the name.

  HOW TO USE THIS FILE
    Press Apply and open the Parameters panel. The patch plays an 8-step
    melody (no input needed) with RESTS: a pattern says which of the 8 steps
    play, and it changes every bar (4 patterns). Steps 1 and 5 are ACCENTED
    (louder). Each
    numbered block of code below writes ONE kind of card and says what you
    should see. Keep the Gain slider around 0.7.

    SYNTH GROUP (cards next to the Gain slider, in the order of the code)
      1  Envelope   fixed range 0..1: a solid level bar with a ruler;
                    stays empty on the rests
      2  Gate       lamp: ON during the first half of each note, OFF on rests
      3  Drift      no range: a ring sliding on a dashed track between
                    the min/max seen so far (in italics)
      4  Pitch      sparkline: the melody as a curve over the last 5 s
      5  Step       STEPS: ONE channel, a whole number 0..7 = WHERE the
                    sequencer is. 8 cells, the current one lit, the ones
                    already passed dimmed, "3 / 7" on the right
      6  Note       text display, built with sprintfk: "E4  120 BPM  A",
                    or "rest  120 BPM  A" (note, tempo, pattern)

    MONITOR GROUP (bottom of the panel)
      7  Light      EIGHT channels, each 0 or 1 = WHICH steps play in this
                    bar (the pattern): several lamps on at once, a new
                    pattern every bar. Compare with Step: Step is one
                    position, Light is eight independent switches.
                    CREATED AT RUN TIME: the card appears by itself 3
                    seconds after Apply (written by instr 2, started by
                    the score at 3 s).
      8  Harm       one card, 4 vertical bars: amplitude of each partial
      9  Voice      audio meter: green/yellow/red segments + peak line
     10  Pan        range -1..1 crosses zero: a half-moon dial with a
                    needle, zero at the top, left blue, right teal
     11  Out        two audio channels Out1/Out2: two vertical meters (L/R)

    NOT SHOWN, on purpose (block 0)
      Gain          a parameter: chnset on it would move its slider
      HOST_BPM      host channels are read, never shown
      Status_ident  "visible(1)" is a Cabbage GUI message: ignored

  Lamps start as an empty bar and turn into a lamp after about a second,
  as soon as the channel has been seen at 1: a channel that has only ever
  been 0 could be a counter, so it is not drawn as a switch. A channel
  stuck at 0 therefore looks like an empty card.

  Two Csound facts this file takes into account:
    - chnset creates its channel at INIT time, even inside an "if" that is
      false: to make a channel appear later, start an instrument later
      (block 7, instr 2).
    - A channel name built at run time with sprintfk and an expression
      ("Light%d", kl + 1) is wrong at init, because the expression is only
      computed at k-time: Csound creates a ghost channel ("Light0") stuck
      at 0. Use literal names (block 7).

  Parameters menu (+) > Channels... (Cmd+4) lists every channel with its
  origin. MonitorStressTest.csd is the same at scale.
*/

sr     = 48000
ksmps  = 32
nchnls = 2
0dbfs  = 1

; ---------------------------------------------------------------------------
; Ranges. Only channels that need a RANGE (or "spark") are declared; all the
; others are created by their first chnset.
;
;   chn_k  name, mode, itype, default, min, max, x, y, w, h, "attributes"
;     mode 2  = output (written by the code)
;     itype 2 = linear range (with itype 0 Csound drops range AND attribute)
;     x, y, w, h: CsoundQt/Cabbage geometry, unused by apeCsound
; ---------------------------------------------------------------------------
chn_k "Envelope", 2, 2, 0,   0,   1                          ; block 1
chn_k "Pitch",    2, 2, 220, 110, 880, 0, 0, 0, 0, "spark"   ; block 4
chn_k "Step",     2, 2, 0,   0,   7                          ; block 5
chn_k "Pan",      2, 2, 0,  -1,   1                          ; block 10

giScale[] fillarray 0, 2, 4, 5, 7, 9, 11, 12
; four rhythm patterns, 8 steps each: 1 = the step plays, 0 = rest
gSPat[]   fillarray "A", "B", "C", "D"
gkpat     init 0                       ; current pattern, shared with instr 2
giPat[]   fillarray 1,1,1,1,1,1,1,1,  1,0,1,1,1,0,1,0,  1,1,0,1,1,1,0,1,  1,0,0,1,1,0,1,1
gSNames[] fillarray "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"

instr 1

  ; ===== 0. NOT SHOWN: a parameter and a host channel, only read ==========
  kgain  chnget "Gain"                 ; parameter (Float 0..1): a slider
  kbpm   chnget "HOST_BPM"             ; host tempo (120 in the standalone app)
  kbpm   = (kbpm > 0 ? kbpm : 120)

  ; --- the sequencer: 8 eighth notes at the host tempo, steps 1 and 5 loud --
  ktick  metro kbpm / 60 * 2
  kstep  init 7
  knote  init 60
  kpat   init 3
  if ktick == 1 then
    kstep = (kstep + 1) % 8
    if kstep == 0 then
      kpat = (kpat + 1) % 4            ; a new pattern every bar
    endif
    knote = 60 + giScale[kstep]
    chnset "visible(1)", "Status_ident"  ; 0: Cabbage GUI message, ignored
  endif
  kacc   = (kstep % 4 == 0 ? 2 : 1)    ; accent on steps 1 and 5
  kon    = giPat[kpat * 8 + kstep]     ; 1 = this step plays, 0 = rest

  ; Everything written below this line, up to "; @group" (or endin), goes in
  ; the "Synth" group, next to the Gain slider, in the order of the code.
  ; @group Synth

  ; ===== 1. LEVEL BAR - chn_k "Envelope" 0..1 (declared range) ============
  ; A solid bar with a ruler: it drops from full to empty on every note, and
  ; stays empty on the rests.
  kenv   = 1 - phasor:k(kbpm / 60 * 2)
  kenv   = kenv * kenv * kon
  chnset kenv, "Envelope"

  ; ===== 2. LAMP - a channel that is only ever 0 or 1 =====================
  ; No declaration, no attribute: after a second it becomes a lamp.
  ; ON for the first half of each note, then OFF; OFF on the rests.
  chnset (kenv > 0.25 ? 1 : 0), "Gate"

  ; ===== 3. ADAPTIVE TRACK - no chn_k, so no range ========================
  ; A slow random detune in cents (2..20, always positive: a range that
  ; crossed zero would turn it into a dial, and that is Pan's job).
  ; A ring slides on a dashed track between the lowest/highest values seen
  ; (shown in italics).
  kdrift rspline 2, 20, 0.2, 0.6
  chnset kdrift, "Drift"

  ; ===== 4. SPARKLINE - chn_k ... "spark" ==================================
  ; The pitch in Hz, smoothed: the curve draws the melody, glides included.
  kcps   portk cpsmidinn(knote) * cent(kdrift), 0.03
  chnset kcps, "Pitch"

  ; ===== 5. STEPS - chn_k "Step" 0..7, only whole numbers written =========
  ; A range with whole ends (3 to 33 values) that only ever receives whole
  ; numbers becomes a row of cells, one per value: the position of a
  ; sequencer. Write a fractional value once and it is a plain bar for good.
  chnset kstep, "Step"

  ; ===== 6. TEXT - a string channel, formatted with sprintfk ==============
  ; One line of state: note (or "rest"), tempo, pattern letter. Units,
  ; decimals, anything: build the string, the display shows it as it is.
  if ktick == 1 then
    if kon == 1 then
      Snote sprintfk "%s%d", gSNames[knote % 12], int(knote / 12) - 1
    else
      Snote strcpyk "rest"
    endif
    Sline sprintfk "%s  %.0f BPM  %s", Snote, kbpm, gSPat[kpat]
    chnset Sline, "Note"
  endif

  ; End of the Synth group: the cards below go to the Monitor group.
  ; @group

  gkpat  = kpat                       ; for instr 2 (block 7)

  ; ===== 8. MULTI-BAR CARD - Harm1..Harm4 ==================================
  ; Four partials whose amplitudes move slowly: one card, four bars.
  kh1    = 0.6 + 0.4 * oscil:k(1, 0.11)
  kh2    = 0.5 + 0.5 * oscil:k(1, 0.17, -1, 0.25)
  kh3    = 0.4 + 0.4 * oscil:k(1, 0.23, -1, 0.5)
  kh4    = 0.3 + 0.3 * oscil:k(1, 0.31, -1, 0.75)
  chnset kh1, "Harm1"
  chnset kh2, "Harm2"
  chnset kh3, "Harm3"
  chnset kh4, "Harm4"

  ; ===== 9. AUDIO METER - chnset on an a-rate signal ======================
  ; The voice before panning. Segmented meter in dB (-60..0), rises at once,
  ; falls slowly; the thin line is the peak, held for a second. The accented
  ; steps (1 and 5, twice as loud) push it higher.
  asig   = poscil(kh1, kcps) + poscil(kh2, kcps * 2) + poscil(kh3, kcps * 3) + poscil(kh4, kcps * 4)
  asig   = asig * a(kenv * kacc) * 0.12 * kgain
  chnset asig, "Voice"

  ; ===== 10. BIPOLAR DIAL - chn_k "Pan" -1..1 ==============================
  ; A slow auto-pan: -1 = left, +1 = right. A half-moon dial with a needle,
  ; zero at the top, blue to the left, teal to the right.
  kpan   = 0.5 + 0.4 * oscil:k(1, 0.25)
  chnset (kpan - 0.5) * 2.5, "Pan"
  aL     = asig * sqrt(1 - kpan)
  aR     = asig * sqrt(kpan)
  outch 1, aL, 2, aR

  ; ===== 11. MULTI AUDIO METER - Out1, Out2 ================================
  ; Two audio channels with an index: one card, two vertical meters. Watch
  ; them swap as the Pan bar above moves.
  chnset aL, "Out1"
  chnset aR, "Out2"

endin

  ; ===== 7. ROW OF LAMPS, CREATED AT RUN TIME - Light1..Light8 ===========
  ; Same prefix + index -> one card; values 0/1 -> lamps instead of bars.
  ; Each lamp says whether that step PLAYS in the current pattern: several
  ; are on at once, and they change every bar. (Step, block 5, is the
  ; position instead: one channel, one lit cell.)
  ; The score starts this instrument 3 seconds after Apply: before that the
  ; Light channels do not exist, then the card appears by itself, without
  ; pressing Apply again. (A chnset in instr 1, even inside an "if", would
  ; create the channels at once.)
  ; Literal names on purpose (see the note at the top about "Light0").
instr 2
  kpat   = gkpat
  chnset giPat[kpat * 8 + 0], "Light1"
  chnset giPat[kpat * 8 + 1], "Light2"
  chnset giPat[kpat * 8 + 2], "Light3"
  chnset giPat[kpat * 8 + 3], "Light4"
  chnset giPat[kpat * 8 + 4], "Light5"
  chnset giPat[kpat * 8 + 5], "Light6"
  chnset giPat[kpat * 8 + 6], "Light7"
  chnset giPat[kpat * 8 + 7], "Light8"
endin

</CsInstruments>
<CsScore>
i1 0 z
i2 3 z
e
</CsScore>
</CsoundSynthesizer>
<apeCsoundParams>
<?xml version="1.0" encoding="UTF-8"?>

<APE_CSOUND_STATE>
  <CHANNEL_PARAM_SLOTS>
    <SLOT index="0" channel="Gain" min="0.0" max="1.0" default="0.7"
          skew="1.0" step="0.0"/>
  </CHANNEL_PARAM_SLOTS>
  <INT_PARAM_SLOTS/>
  <BOOL_PARAM_SLOTS/>
  <CHOICE_PARAM_SLOTS/>
</APE_CSOUND_STATE>

</apeCsoundParams>
