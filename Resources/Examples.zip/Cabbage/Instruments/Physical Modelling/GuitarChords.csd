; apeCsound: rewritten for plugin parameters - Fret/Tune Int per string, Strum toggle + Auto BPM (see <Cabbage> and instr 1); groupbox -> groups

/* Attribution-NonCommercial-ShareAlike 4.0 International
Attribution - You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
NonCommercial - You may not use the material for commercial purposes.
ShareAlike - If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.
https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode */

; GuitarChords.csd
; Written by Iain McCurdy, 2012.

<Cabbage>
form size(650, 265), caption("Guitar Chords"), pluginId("guit"), guiRefresh(64)

; apeCsound: the original fretboard (90 radio checkboxes + 6 tuning comboboxes
; of ~100 entries) cannot be mapped to plugin parameters (32 toggles, 16 menu
; options). Each string is now an Int "Fret" (-1 = muted, 0 = open, 1..13) and
; an Int "Tune" (MIDI note of the open string). Defaults = an open E major chord.
groupbox bounds(  0,  0, 320, 140), text("Frets (-1 = mute, 0 = open)") {
nslider bounds( 10, 25, 45, 30), text("High E"), channel("HighE_Fret"), range(-1, 13, 0, 1, 1)
nslider bounds( 60, 25, 45, 30), text("B"),      channel("B_Fret"),     range(-1, 13, 0, 1, 1)
nslider bounds(110, 25, 45, 30), text("G"),      channel("G_Fret"),     range(-1, 13, 1, 1, 1)
nslider bounds(160, 25, 45, 30), text("D"),      channel("D_Fret"),     range(-1, 13, 2, 1, 1)
nslider bounds(210, 25, 45, 30), text("A"),      channel("A_Fret"),     range(-1, 13, 2, 1, 1)
nslider bounds(260, 25, 45, 30), text("Low E"),  channel("LowE_Fret"),  range(-1, 13, 0, 1, 1)
}
groupbox bounds(320,  0, 330, 140), text("Tuning (MIDI note of the open string)") {
nslider bounds( 10, 25, 45, 30), text("High E"), channel("HighE_Tune"), range(30, 90, 64, 1, 1)
nslider bounds( 60, 25, 45, 30), text("B"),      channel("B_Tune"),     range(30, 90, 59, 1, 1)
nslider bounds(110, 25, 45, 30), text("G"),      channel("G_Tune"),     range(30, 90, 55, 1, 1)
nslider bounds(160, 25, 45, 30), text("D"),      channel("D_Tune"),     range(30, 90, 50, 1, 1)
nslider bounds(210, 25, 45, 30), text("A"),      channel("A_Tune"),     range(30, 90, 45, 1, 1)
nslider bounds(260, 25, 45, 30), text("Low E"),  channel("LowE_Tune"),  range(30, 90, 40, 1, 1)
}
groupbox bounds(  0,140, 650, 125), text("Strum") {
checkbox bounds(  5, 25,100, 20), channel("strum"), text("Strum"), value(0)
hslider  bounds(  5, 50,170, 40), text("Auto BPM"), channel("AutoBPM"), range(0, 240, 70, 1, 1)
combobox bounds(185, 50, 85, 25), channel("GuitarType"), value(1), text("6 String","12 String")
checkbox bounds(185, 25,100, 20), channel("ReverseStrum"), text("Reverse") colour("lime")
hslider bounds(280, 25,350, 40), text("Gap"),    colour("tan"), fontColour(195,126,  0), channel("gap"),   range(0,0.5,0.05,0.5,0.0001)
hslider bounds(280, 50,350, 40), text("Damp"),   colour("tan"), fontColour(195,126,  0), channel("damp"),   range(0.01,0.99,0.17)
hslider bounds(280, 75,350, 40), text("Pos."),   colour("tan"), fontColour(195,126,  0), channel("pos"),   range(0.0001, 0.5, 0.02, 0.5, 0.001)
}
</Cabbage>

<CsoundSynthesizer>
<CsOptions>
-n -dm0 -+rtmidi=NULL -M0 --midi-key-cps=4 --midi-velocity-amp=5
</CsOptions>
<CsInstruments>

; sr set by host
ksmps = 64
nchnls = 2
0dbfs = 1

; A small amount of fixed random detuning improves the 12 string guitar sound
iDetuneRange    =    0.025
gidetune    ftgen    0, 0, 8, -21, 6, iDetuneRange    ; table of detuning values for each string in a 12 string guitar configuration

instr    1
 ; apeCsound: one Int "Fret" (-1 mute / 0 open / 1..13) and one Int "Tune"
 ; (MIDI note of the open string) per string, instead of the Cabbage
 ; fretboard of radio checkboxes and the 100-entry tuning menus.
 #define    STRING_SETUP(NAME)
 #
 k$NAME._Fret    chnget    "$NAME._Fret"
 k$NAME._Tune    chnget    "$NAME._Tune"
 k$NAME._Mute    =         (k$NAME._Fret < 0 ? 1 : 0)
 kCps$NAME       =         cpsmidinn(k$NAME._Tune + max(0, k$NAME._Fret))
 #
 $STRING_SETUP(HighE)
 $STRING_SETUP(B)
 $STRING_SETUP(G)
 $STRING_SETUP(D)
 $STRING_SETUP(A)
 $STRING_SETUP(LowE)

 #define    PLAY_STRING(NAME'N)
 #
 if(k$NAME._Mute==1) kgoto SKIP$NAME                ; if this is an open and muted string jump string playing code
 kRndStrt    random    0,kgap*0.15
 schedkwhen    ktrig,0,0,2.$N,kstart+kRndStrt,20,kCps$NAME,$N    ; play string (instr 2)
 kstart    =    kstart + kgap                    ; increment start time
 SKIP$NAME:                            ; label
 if k$NAME._Mute==1 then
  turnoff2    2.$N,4,1                        ; turn off string  
 endif
 if changed(kCps$NAME)==1 && timeinstk()>1 then                        ; ...
  turnoff2    2.$N,4,1                        ; turn off string
  event    "i",2.$N,0,20,kCps$NAME,$N
 endif
 #

 ; "Strum" is a toggle in the plugin: every switch ON (or OFF) strums once.
 ; "Auto BPM" > 0 strums by itself (0 = off), so the patch plays after Apply.
 kstrum    chnget    "strum"
 kAutoBPM  chnget    "AutoBPM"
 ktrig     changed   kstrum
 if kAutoBPM > 0 then
  ktrig   =  (metro(kAutoBPM/60) == 1 ? 1 : ktrig)
 endif
 if timeinstk() == 1 then
  ktrig   =  0
 endif
 if ktrig==1 then                        ; ...
  turnoff2    2,0,1                        ; turn off all playing strings (in preparation for the new chord)
 endif
 kgap    chnget    "gap"
 kreverse    chnget    "ReverseStrum"
 if kreverse==0 then
  kstart    =    0                    ; start time (for first string plucked)
 else
  kstart    =    kgap*5
  kgap        =    -kgap
 endif
 $PLAY_STRING(LowE'1)
 $PLAY_STRING(A'2)
 $PLAY_STRING(D'3)
 $PLAY_STRING(G'4)
 $PLAY_STRING(B'5)
 $PLAY_STRING(HighE'6)
endin














instr    2    ; string pluck
 kdamp    chnget    "damp"    ; damping
 iplk    chnget    "pos"    ; pluck position
 iamp    random    0.1,0.2
 
 iGuitarType    chnget    "GuitarType"
  if(iGuitarType==2) then                    ; if 12 string guitar...
  kmvt1    jspline        0.15,0.2,0.4                ; a bit of random pick-up movement animates the tone of the guitar    
  kmvt2    jspline        0.15,0.2,0.4        
  idtn    table        p5,gidetune                ; detuning value. used in 12 string guitar only.
  if p5<5 then                            ; strings 1 - 4 are in octaves in a 12-string guitar
   a1    wgpluck2    iplk, iamp/2, p4,          0.2+kmvt1, kdamp
   a2    wgpluck2    iplk, iamp/2, p4*(2+idtn), 0.2+kmvt2, kdamp
  else                                ; strings 5 & 6 are in unison in a 12-string guitar
   a1    wgpluck2    iplk, iamp/2, p4,          0.2         +kmvt1, kdamp
   a2    wgpluck2    iplk, iamp/2, p4*(1+idtn), 0.2+rnd(0.5)+kmvt2, kdamp
  endif
   a2    delay    a2,0.01+rnd(0.01)                ; slight delay to second string
  asig    =    a1+a2
 else                                    ; otherwise 6 string
  kmvt    jspline        0.15,0.2,0.4        
  asig    wgpluck2    iplk, iamp, p4,   0.2+kmvt,          kdamp
 endif
 
 aenv        linsegr    0, 0.0008, 1, p3-0.1008, 0, 0.05, 0    ; amplitude envelope. Attack removes excessive 'click'. Decays to nothing across note duration (p3). Short release stage prevents click if a note is interrupted.
 
 /* FILTERING TO IMPROVE THE SOUND */
 af1    resonz    asig,200,200
 af2    resonz    asig,550,550
 af3    resonz    asig,2100,2100
 asig    sum    af1,af2*5,af3
 asig    =    asig/200
 /* ------------------------------ */
 
 asig    =    asig*aenv
     outch 1, asig, 2, asig
endin




</CsInstruments>  

<CsScore>
i 1 0 [3600*24*7]
</CsScore>

</CsoundSynthesizer>