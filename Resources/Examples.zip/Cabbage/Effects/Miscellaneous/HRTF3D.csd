; apeCsound: 4 cabbageGetValue -> chnget; 4 cabbageSet lines disabled (GUI only); xypad -> XY pad card; reinit of hrtfmove2 only when HeadRadius/Overlaps change.

/* Attribution-NonCommercial-ShareAlike 4.0 International
Attribution - You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
NonCommercial - You may not use the material for commercial purposes.
ShareAlike - If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.
https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode */

; HRTF3D.csd
; Written by Iain McCurdy, 2012.

; 3D rendering of a mono input from the left channel.
; Uses head related transfer function transformation (HRTF) and the hrtfmove2 opcode
; Azimuth (horizontal angle with respect to a front-facing listener) and
;  elevation (vertical angle) are both specified in degrees and can be controlled using the XY pad control

; N STFT Overlaps (number of short time fourier transform overlaps)  - larger numbers provide smoother 
;  interpolation at the expense of computation speed

; Head radius (in cm) varies the interaural time delay and is particularly impactful on lower frequencies.
;  the default is 9 cm which is the average for an adult human.

; The display widgets on right attempts to visualise the movement (left-right, up-down, near-far) 
;   of the source sound.
; Brightness of the source sound widget (red circle) varies according to the intensity of the input signal.
; Size of the source sound widget reflects distance front to back.

<Cabbage>
form caption("HRTF 3D"), size(800, 450), pluginId("HRTF"), colour(0,0,0) guiMode("queue")
xypad bounds(0,  0, 400, 400), channel("Az","Elev"), text("X=Azimuth (degs) | Y=Elev. (degs)"), rangeX(-180,  180,   0), rangeY(-40, 90, 0)

image bounds(500,180,  30, 30), colour(200,50,50), shape("ellipse"), channel("SoundSource")

image bounds(560,145,100,100) colour(0,0,0,0) channel("Face") {
image bounds(   2,  0,  81, 100), colour(200,200,150), shape("ellipse")
image bounds(   0, 30,   6,  30), colour(200,200,150), shape("ellipse")
image bounds(  79, 30,   6,  30), colour(200,200,150), shape("ellipse")
image bounds(   20,  33,  20,  10), colour(10,10,10), shape("ellipse")
image bounds(   50,  33,  20,  10), colour(10,10,10), shape("ellipse")

image bounds(   38,  55,  15,   6), colour(10,10,10), shape("ellipse")
image bounds(   38,  52,  15,   6), colour(200,200,150), shape("ellipse")


image bounds(   25,  65,  40,  12), colour(10,10,10), shape("ellipse")
image bounds(   25,  62,  40,   8), colour(200,200,150)
}

image bounds(  0,400,800,50), colour(40,40,40), outlineThickness(2), outlineColour("Silver")
{
hslider bounds(  5, 10, 390, 30), channel("HeadRadius"), text("Head Radius (cm)"), range(1,30,9) valueTextBox(1)
hslider bounds(405, 10, 390, 30), channel("Overlaps"), text("N. STFT Overlaps"), range(2,16,4,1,1) valueTextBox(1)
}

</Cabbage>

<CsoundSynthesizer>

<CsOptions>
-d -n
</CsOptions>

<CsInstruments>

; REQUIRED: the HRTF data files. hrtfmove2 loads
;   hrtf-44100-left.dat  hrtf-44100-right.dat
;   hrtf-48000-left.dat  hrtf-48000-right.dat
;   hrtf-96000-left.dat  hrtf-96000-right.dat
; from the SADIR folder (apeCsound/SADIR, see Main menu > Config). They
; ship with Csound (source tree: samples/, macOS package:
; /usr/local/share/csound/samples or Csound.app/Contents/Resources/samples).
; Without them the console prints "cannot load hrtf-...dat, or SADIR
; undefined" and the instrument produces no sound. Only 44.1, 48 and 96
; kHz are available: at other sample rates the 96k set is used (wrong result).
; Standalone: press "Unmute" in the yellow bar, the input is muted by default.

; sr set by host
ksmps    =     16
nchnls   =     2
0dbfs    =     1

;Author: Iain McCurdy (2012)

instr    1
    
    kAz        chnget        "Az"                                  ; READ WIDGETS...
    ;kAz        scale                  kAz, 180, -180
    kElev      chnget        "Elev"
    ;kElev      scale                  kElev, 90, -40
    
    ; audio input
    ;asrc       diskin2                 "Benjamin.wav",1,0,1
    asrc       inch                    1
    iSR   =    sr
    if iSR==44100 then
        SdataL = "hrtf-44100-left.dat"
        SdataR = "hrtf-44100-right.dat"
    elseif iSR==48000 then
        SdataL = "hrtf-48000-left.dat"
        SdataR = "hrtf-48000-right.dat"
    else
        SdataL = "hrtf-96000-left.dat"
        SdataR = "hrtf-96000-right.dat"
    endif
    
    kHeadRadius chnget "HeadRadius"
    kOverlaps   chnget "Overlaps"
    
    ; apeCsound: in Cabbage the second output of cabbageGetValue was a
    ; TRIGGER (1 only when the widget moves). Summing the values instead
    ; made the condition always true, so hrtfmove2 was re-initialised on
    ; every k-cycle and never produced any output. Reinit only on change.
    if changed(kHeadRadius, kOverlaps) == 1 then
        reinit RESTART
    endif
    RESTART:
    iOverlaps   = (i(kOverlaps) < 2 ? 4 : int(i(kOverlaps)))
    iHeadRadius = (i(kHeadRadius) <= 0 ? 9 : i(kHeadRadius))
    aleft, arig hrtfmove2    asrc, kAz, kElev, SdataL, SdataR, iOverlaps, iHeadRadius, sr
    rireturn
    outch 1, aleft, 2, arig; SEND AUDIO TO OUTPUTS
    
    kRMS       rms           asrc
    ;printk     0.1,kRMS
    
    kX  mirror  kAz/90, -1, 1
    kSize =     (180 - abs(kAz))/180
    
    kSizeE   =  (180 - abs(kElev))/180
    
    ; front/back
    kFB   =     round(kSize>0.5?1:0)
    
    ; apeCsound: GUI-only, disabled -> cabbageSet changed:k(kAz,kElev), "SoundSource", "bounds", kX*180 + 590, 180 - kElev*2, 15 + kSize*30*kSizeE, 15 + kSize*30*kSizeE
    ; apeCsound: GUI-only, disabled -> cabbageSet changed:k(kRMS), "SoundSource", "colour", 100 + kRMS*55*4, 10 + kRMS*205*4, 10 + kRMS*205*4
    ; apeCsound: GUI-only, disabled -> cabbageSet trigger:k(kFB,0.5,0), "SoundSource", "toFront"
    ; apeCsound: GUI-only, disabled -> cabbageSet trigger:k(kFB,0.5,1), "Face", "toFront"
    
endin

</CsInstruments>

<CsScore>
i 1 0 [3600*24*7]
</CsScore>

</CsoundSynthesizer>

<apeCsoundParams>
<?xml version="1.0" encoding="UTF-8"?>

<APE_CSOUND_STATE>
  <CHANNEL_PARAM_SLOTS>
    <SLOT index="0" channel="Az" min="-180.0" max="180.0" default="0.0"
          skew="1.0" step="0.001000000047497451"/>
    <SLOT index="1" channel="Elev" min="-40.0" max="90.0" default="0.0"
          skew="1.0" step="0.001000000047497451"/>
    <SLOT index="2" channel="HeadRadius" min="1.0" max="30.0" default="9.0"
          skew="1.0" step="0.001000000047497451"/>
    <SLOT index="3" channel="Overlaps" min="2.0" max="16.0" default="4.0"
          skew="1.0" step="1.0"/>
  </CHANNEL_PARAM_SLOTS>
  <INT_PARAM_SLOTS/>
  <BOOL_PARAM_SLOTS/>
  <CHOICE_PARAM_SLOTS/>
</APE_CSOUND_STATE>

</apeCsoundParams>
