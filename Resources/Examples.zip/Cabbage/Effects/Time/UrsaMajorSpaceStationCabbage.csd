; apeCsound: Csound 7 fix - the delay line is a function
; table written with tablew and read with tablei, instead of delayr / deltapi
; / delayw. In Csound 7 the deltap family pairs with the delayr of its own
; instance, so taps inside (recursive) UDOs no longer see the delay buffer
; of the calling instrument. Same taps, same sound.

/* Attribution-NonCommercial-ShareAlike 4.0 International
Attribution - You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
NonCommercial - You may not use the material for commercial purposes.
ShareAlike - If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.
https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode */

; URSA MAJOR SPACE STATION
; Iain McCurdy, 2021

; Clone of Ursa Major Space Station SST-282 multitap delay

<Cabbage>
form caption("Ursa Major Space Station"), size(680, 415), pluginId("UMSS"), colour("white")
#define RSliderStyle  trackerInsideRadius(.9), trackerOutsideRadius(1), markerColour(10,10, 55), markerThickness(2), trackerColour(130,130,255), trackerThickness(4), colour(160,165,180), fontColour(50,50,50), textColour(50,50,50), outlineColour(50,50,50), valueTextBox(1)
label   bounds(  0, 10, 680,20), text("U  R  S  A     M  A  J  O  R  -  S  P  A  C  E     S  T  A  T  I  O  N"), align("centre"), fontColour("black")
line    bounds(  5, 35, 670, 2)
rslider bounds( 10, 40, 90, 90), text("Low Cut"), channel("LowCut"), range(50, 1000, 200, 0.5, 1), $RSliderStyle
rslider bounds( 90, 40, 90, 90), text("High Cut"), channel("HighCut"), range(1000, 15000, 8000, 0.5, 1), $RSliderStyle
rslider bounds(170, 40, 90, 90), text("Feedback"), channel("FBRatio"), range(0, 1, 0.85), $RSliderStyle
rslider bounds(250, 40, 90, 90), text("Damping"), channel("Damping"), range(500, 15000, 10000, 0.5, 1), $RSliderStyle
rslider bounds(330, 40, 90, 90), text("Size"), channel("Size"), range(0.1, 1, 0.5), $RSliderStyle
rslider bounds(410, 40, 90, 90), text("Mix"), channel("DryWet"), range(0, 1, 0.7), $RSliderStyle
rslider bounds(490, 40, 90, 90), text("Decay"), channel("Decay"), range(0, 24, 24,1,1), $RSliderStyle
rslider bounds(570, 40, 90, 90), text("Modulation"), channel("Modulation"), range(0.1, 10, 1), $RSliderStyle
line    bounds(  5,140, 670, 2)
image   bounds(115,150,450,250), file("Schematic.png") 
</Cabbage>

<CsoundSynthesizer>
<CsOptions>
-dm0 -n -+rtmidi=NULL -M0
</CsOptions>
<CsInstruments>

ksmps = 32
nchnls = 2
0dbfs = 1

seed 0		; this line ensures that certain random number generators will be seeded from the system clock each time Csound is run, ensuring that the results will be different each time.

; delay buffers (one per channel): 65536 samples cover iMaxDelay (0.255 s)
; up to sr = 192 kHz. Written with tablew at the write phase aPhs, read by
; the taps with tablei (linear interpolation) at aPhs - delay.
giDelL	ftgen	0, 0, 65536, 2, 0
giDelR	ftgen	0, 0, 65536, 2, 0

opcode	ListenerTaps, a, akkiiip																					; define the form of the user defined opcode	
 aPhs, kSize, kDecay, iMaxDelay, iNLisTaps, iTab, iCount	xin									; read the input variables (aPhs = write phase 0..1, iTab = delay table)
 iLen	=										ftlen(iTab)
 iTime	=										(iCount/iNLisTaps) * iMaxDelay				; spread the taps evenly across the delay range
 iTime	+=									random:i(-iMaxDelay/iNLisTaps,iMaxDelay/iNLisTaps) * 0.5		; add some randomness to the delay time of each tap
 iTime	limit						iTime,1/kr,iMaxDelay													; limit the delay times in case the randomness caused any to exceed the buffer.
 kDel		=										iTime*kSize																			; delay time, scaled according to the 'Size' control.
 aTap		tablei					aPhs - kDel*sr/iLen, iTab, 1, 0, 1										; tap the delay buffer (normalised index, wrap around)
 aTap		*=									ampdbfs((iCount/iNLisTaps)* kDecay)			; scale the amplitude of each tap. Later taps will be quieter.
 aMix		init								0
 if (iCount < iNLisTaps) then																									; conditionally call the UDO again
  aMix	ListenerTaps	aPhs, kSize, kDecay, iMaxDelay, iNLisTaps, iTab, iCount+1	; call the UDO again and increment the counter (iCount)
 endif
 									xout				aTap + aMix																				; send audio back to caller instrument	, both the audio from the first layer mixed with all subsequent layers
endop

opcode	FeedbackTaps, a, akkiiip																					; define the form of the user defined opcode	
 aPhs, kSize, kModulation, iMaxDelay, iNFBTaps, iTab, iCount	xin						; read the input variables
 iLen	=										ftlen(iTab)
 kRate	rspline					kModulation, kModulation*2, 0.2, 0.5														; rate of change of the random fucntion in the next line
 aTime	randomi					0, iMaxDelay, kRate, 1											; a random function (linear segments) defines the delay tap position (time)
 aDel		limit						aTime*kSize, 1/kr, iMaxDelay											; scale according to the 'Size' control, keep inside the buffer
 aTap		tablei					aPhs - aDel*sr/iLen, iTab, 1, 0, 1										; tap the delay buffer (normalised index, wrap around)
 aMix		init								0
 if (iCount < iNFBTaps) then																						; conditionally call the UDO again
  aMix	FeedbackTaps	aPhs, kSize, kModulation, iMaxDelay, iNFBTaps, iTab, iCount+1	; call the UDO again and increment the counter (iCount)
 endif
 									xout				aTap + aMix																			; send audio back to caller instrument	
endop

instr		1
 
 ; retrigger a sample periodically
 /*
 if metro(0.3)==1 then
  reinit RESTART
 endif
 RESTART:
 aIn				diskin	"Snare.wav"
 rireturn
 */
 
 aInL inch 1
 aInR inch 2
 
 
 iNLisTaps		=		8				; number of listener taps (stationary)
 iNFBTaps			=		15			; number of feedback taps (modulated)
 
 iMaxDelay	=	 0.255
 kCF						chnget		"Damping"
 kFBRatio		chnget		"FBRatio"
 kFBRatio		*=						0.4
 kPortTime	linseg		0,0.01,0.05
 kSize				chnget		"Size"
 kSize				portk			kSize, kPortTime
 kDecay				chnget		"Decay"
 kModulation	chnget	"Modulation"
 
 aInLFilt			buthp	aInL, chnget:k("LowCut")
 aInLFilt			butlp	aInLFilt, chnget:k("HighCut")

 aInRFilt			buthp	aInR, chnget:k("LowCut")
 aInRFilt			butlp	aInRFilt, chnget:k("HighCut")
 
 
 iLen	=	ftlen(giDelL)
 aPhs	phasor	sr/iLen											; write phase of the delay tables (0..1), one full turn = iLen samples

 aLisL	ListenerTaps	aPhs, kSize, -kDecay, iMaxDelay, iNLisTaps, giDelL, 1
 aFBL		FeedbackTaps	aPhs, kSize, kModulation, iMaxDelay, iNFBTaps, giDelL, 1
 aFBL		dcblock2					aFBL
 aFBL		clip								aFBL, 0, 0.9
 aFBL		tone								aFBL, kCF
 					tablew aInLFilt + ( (aFBL/(iNFBTaps^0.02)) * kFBRatio ), aPhs, giDelL, 1		; write input + feedback into the delay table

 aLisR	ListenerTaps	aPhs, kSize, -kDecay, iMaxDelay, iNLisTaps, giDelR, 1
 aFBR		FeedbackTaps	aPhs, kSize, kModulation, iMaxDelay, iNFBTaps, giDelR, 1
 aFBR		dcblock2					aFBR
 aFBR		clip								aFBR, 0, 0.9
 aFBR		tone								aFBR, kCF
 					tablew aInRFilt + ( (aFBR/(iNFBTaps^0.02)) * kFBRatio ), aPhs, giDelR, 1
 	
 	kDryWet	chnget	"DryWet"
 	aMixL	ntrpol	aInL, (aLisL*0.3), kDryWet
 	aMixR	ntrpol	aInR, (aLisR*0.3), kDryWet
 	
 					outch 1, aMixL, 2, aMixR
 					

endin

</CsInstruments>

<CsScore>
i 1 0 [3600*24*365]
</CsScore>

</CsoundSynthesizer>
