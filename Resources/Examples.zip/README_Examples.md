# Cabbage and CsoundQt examples in apeCsound

The `Cabbage` and `CsoundQT` folders contain example `.csd` files written for two other Csound frontends, [Cabbage](https://cabbageaudio.com) and [CsoundQt](https://csoundqt.github.io). They are included so that apeCsound users can study and play a large body of existing Csound code. They are **not** original apeCsound material: all credit belongs to their authors, listed below.

## Where they come from

### Cabbage folder (84 files)

From the example collection distributed with Cabbage by Rory Walsh: https://github.com/rorywalsh/cabbage (folder `Examples`).

- **Author:** Iain McCurdy, written between 2012 and 2016 (the year is in each file header).
- **Folders:**
  - `Effects/` (57 files): Distortion, Dynamics, Filters, Modulation, Reverbs, Spectral, Time.
  - `Instruments/` (27 files): DrumMachines, Miscellaneous, Noise, PhysicalModelling, Synths.

### CsoundQT folder (56 files)

From the example collection distributed with CsoundQt (originally written by Andrés Cabrera, maintained by the CsoundQt community): https://github.com/CsoundQt/CsoundQt.

| Folder | Files | Author(s) as stated in the files |
|---|---|---|
| `McCurdy Collection/` | 35 | Iain McCurdy (2006-2011), modified for QuteCsound/CsoundQt by René (2010-2011) |
| `McCurdy Haikus/` | 9 | Iain McCurdy (2011), small code modifications by Joachim Heintz (2024) |
| `Live Collection/` | 3 | Joachim Heintz |
| `Music/Stockhausen Studie II.csd` | 1 | Csound realisation by Joachim Heintz, transcribed from the score of Karlheinz Stockhausen's *Studie II* (1954) |
| `Music/Banados Dew.csd` | 1 | Tom Banados Russell, using the ArrayShuffle UDO by Joachim Heintz |
| `Miscellaneous/Circle_Map.csd` | 1 | Michael Gogins (2012) |
| `Miscellaneous/Filter_lab.csd` | 1 | Filters after Udo Zölzer, *DAFX - Digital Audio Effects* (Chapter 2); author not stated |
| `Synths/`, `Miscellaneous/Noise_Reduction.csd`, `Miscellaneous/Just_Intonation.csd` | 5 | CsoundQt example collection; author not stated in the file |

## Licenses

Each file keeps the license under which it was published. apeCsound does not change it.

- **Cabbage examples by Iain McCurdy (80 of the 84 files):**
  - **License:** the header states [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International](https://creativecommons.org/licenses/by-nc-sa/4.0/) (CC BY-NC-SA 4.0).
  - **What it requires:** credit to the author, no commercial use, and modified versions shared under the same license.
  - **The other 4 files** (`Instruments/Miscellaneous`: CellularAutomata, LorenzSynth, Metronome, Micropolyphony) have no license header. They are part of the Cabbage repository, which is distributed under the GNU GPL v3.
- **CsoundQt examples:**
  - **License:** distributed as part of CsoundQt, licensed under the GNU GPL v3 or, at your option, the GNU LGPL v2.1.
  - **Exception:** `Circle_Map.csd` states its own license, the GNU Library/Lesser GPL v3 (Michael Gogins).

The full license texts are at the links above and in the Cabbage and CsoundQt repositories. If a file's own header says something different from this summary, the header is what applies.

## Changes made for apeCsound

The files have been **partially adapted** to run in apeCsound. The music and the sound-generating code are the authors' work and have been left as they were, as far as possible. The changes are:

- **Controls:**
  - Cabbage `<Cabbage>` widgets and CsoundQt `<bsbPanel>` widgets (sliders, knobs, spin boxes, XY controllers, checkboxes, menus) become apeCsound parameters: DAW-automatable sliders, toggles and menus.
  - The original widget sections are still in the files.
- **Channel opcodes:**
  - `invalue` and `cabbageGetValue` are replaced by `chnget`.
  - `outvalue` and `cabbageSet...` are replaced by `chnset`, or removed.
- **Settings:** small adjustments where needed for a plug-in host. For example, `sr` and the audio/MIDI settings come from the host, so device options in `<CsOptions>` are ignored.

## What is missing

apeCsound is a code editor with DAW parameters, not a graphical frontend. Compared with Cabbage and CsoundQt:

- **The graphical interface is not reproduced.** Panel layout, colours, images, labels, groups, keyboards, tables, meters, displays, XY pads drawn as graphics, presets and the visual design of the original instruments are ignored. Parameters appear as a plain list.
- **Buttons and events:**
  - Event buttons, file choosers and text fields that trigger actions are not available.
  - Widgets that only display values sent from Csound (meters, number boxes, "identchannel" animations) have no equivalent.
- **Unsupported code:**
  - Frontend-specific opcodes and features do not work: Cabbage plants and `cabbage...` opcodes beyond simple get/set, CsoundQt `_Browse` channels, FLTK widgets.
  - Python, Lua and OSC code does not work.
  - Opcodes from plug-in libraries not built into apeCsound do not work.
- **Files and devices:** examples that need external sound files, live input on specific devices or MIDI hardware may need extra setup. Sound files go in the SSDIR folder.

Some examples therefore sound and behave exactly like the originals, others only partially. A few may not run at all without further editing. For the full experience, including the original interfaces, use the examples in Cabbage or CsoundQt.

## References

- **Cabbage:**
  - Rory Walsh: https://cabbageaudio.com
  - Source and examples: https://github.com/rorywalsh/cabbage
- **CsoundQt:**
  - Website: https://csoundqt.github.io
  - Source and examples: https://github.com/CsoundQt/CsoundQt
- **Iain McCurdy:**
  - Csound realtime examples: http://iainmccurdy.org/csound.html
- **Joachim Heintz:**
  - Website: https://joachimheintz.de
  - Csound FLOSS Manual: https://flossmanual.csound.com
- **Csound:** https://csound.com
- **Licenses:**
  - CC BY-NC-SA 4.0: https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode
  - GNU GPL v3: https://www.gnu.org/licenses/gpl-3.0.html
  - GNU LGPL v2.1: https://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
  - GNU LGPL v3: https://www.gnu.org/licenses/lgpl-3.0.html
